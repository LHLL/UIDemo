//
//  FootageCell.swift
//  Groupreel
//
//  Created by Lynn on 11/3/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

protocol FootageCellDelegate: class {
    func buyMoreFootage()
}

class FootageCell: UITableViewCell {
    
    @IBOutlet weak var endMin: UILabel!
    @IBOutlet weak var endHour: UILabel!
    @IBOutlet weak var startMin: UILabel!
    @IBOutlet weak var startHour: UILabel!
    @IBOutlet weak var buyBtn: UIButton!
    @IBOutlet weak var container: UIView!
    @IBOutlet weak var durationLeft: UIProgressView!
    
    private var flag = true
    private var gradientLayer: CAGradientLayer!
    weak var delegate:FootageCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        container.layer.cornerRadius = 10
        container.layer.cornerRadius = 10
        layer.cornerRadius = 10
        layer.masksToBounds = true
        buyBtn.layer.cornerRadius = buyBtn.frame.size.height / 2
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        contentView.layer.cornerRadius = 5
        if flag {
            flag = false
            buttonSetup()
        }
    }
    
    private func buttonSetup() {
        //footage view gradient
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = buyBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        buyBtn.layer.insertSublayer(gradientLayer, at: 0)
        buyBtn.layer.masksToBounds = true
    }

    @IBAction func buyMoreFootage(_ sender: UIButton) {
        delegate?.buyMoreFootage()
    }
    
}
