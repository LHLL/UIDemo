//
//  CodeCell.swift
//  Groupreel
//
//  Created by Lynn on 2/5/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class CodeCell: UITableViewCell {
    
    @IBOutlet weak var codeText: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        layer.cornerRadius = 10
        layer.masksToBounds = true
    }
    
}
