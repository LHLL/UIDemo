//
//  CodeCell.swift
//  Groupreel
//
//  Created by Lynn on 2/5/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class CodeCell: UITableViewCell {
    @IBOutlet weak var codeText: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
