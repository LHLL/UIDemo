//
//  CustomCell.swift
//  Groupreel
//
//  Created by Lynn on 1/3/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit
import JTAppleCalendar

class CustomCell: JTAppleCell {
    @IBOutlet weak var endSelectedView: UIView!
    @IBOutlet weak var endDateLabel: UILabel!
    @IBOutlet weak var dateLabel:UILabel!
    @IBOutlet weak var selectedView:UIView!
    
    override func awakeFromNib() {

    }

}
