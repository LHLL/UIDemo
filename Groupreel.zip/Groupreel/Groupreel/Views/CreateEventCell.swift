//
//  CreateEventCell.swift
//  Groupreel
//
//  Created by Lynn on 2/7/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit
protocol CreateEventCellDelegate{
    func shouldUpdate(name:String)
    func chooseDate()
    func shouldUpdate(duration:Int)
    func update(music:String)
    func updateNote(note:String)
    func toPayment()
}

class CreateEventCell: UITableViewCell {

    @IBOutlet weak var checkoutBtn: UIButton!
    @IBOutlet weak var codeTF: UITextField!
    @IBOutlet weak var unitLabel: UILabel!
    @IBOutlet weak var hourLabel: UILabel!
    @IBOutlet weak var minLabel: UILabel!
    @IBOutlet weak var timeView: UIView!
    @IBOutlet weak var seprator: UIView!
    @IBOutlet weak var noteTF: UITextField!
    @IBOutlet weak var musicTextField: UITextField!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var errorView: UIView!
    @IBOutlet weak var addHour: UIButton!
    @IBOutlet weak var deHour: UIButton!
    @IBOutlet weak var addMin: UIButton!
    @IBOutlet weak var deMin: UIButton!
    @IBOutlet weak var endDate: UILabel!
    @IBOutlet weak var startDate: UILabel!
    @IBOutlet weak var trigger: UIButton!
    @IBOutlet weak var eventNameTF: UITextField!
    
    var price:String!
    var unit:String = "5"
    var delegate:CreateEventCellDelegate?
    
    private var min:Int = 0
    private var hour:Int = 0
    private lazy var musicPicker = UIPickerView()
    private var pickerData = ["Acoustic", "Dance", "Dubstep", "Electronica", "Happy Rock", "Soft Jazz", "Upbeat Jazz"]
    private var gradientLayer: CAGradientLayer!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        UISetup()
        layer.cornerRadius = 5
        seprator.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi/4));
        self.musicPicker.delegate = self
        self.musicPicker.dataSource = self
        picker()
        musicTextField.inputView = self.musicPicker
        checkoutBtn.layer.cornerRadius = checkoutBtn.frame.size.height / 2
        checkoutBtn.layer.masksToBounds = true
    }
    
    override func layoutSubviews() {
        unitLabel.text = "$\(unit)/min"
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = checkoutBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        checkoutBtn.layer.insertSublayer(gradientLayer, at: 0)
        checkoutBtn.layer.masksToBounds = true
    }
    
    private func UISetup() {
        deMin.setImage(IonIcons.image(withIcon: ion_ios_minus_outline, iconColor: GroupreelColor.blingGreen, iconSize: 20, imageSize: CGSize(width: 20, height: 20)), for: .normal)
        deHour.setImage(IonIcons.image(withIcon: ion_ios_minus_outline, iconColor: GroupreelColor.blingGreen, iconSize: 20, imageSize: CGSize(width: 20, height: 20)), for: .normal)
        addHour.setImage(IonIcons.image(withIcon: ion_ios_plus_outline, iconColor: GroupreelColor.blingGreen, iconSize: 20, imageSize: CGSize(width: 20, height: 20)), for: .normal)
        addMin.setImage(IonIcons.image(withIcon: ion_ios_plus_outline, iconColor: GroupreelColor.blingGreen, iconSize: 20, imageSize: CGSize(width: 20, height: 20)), for: .normal)
    }
    
    private func picker() {
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.tintColor = UIColor.lightGray
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(dismissPickerView))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        //        doneButton.accessibilityFrame = CGRect(x: 0, y: 0, width: 200, height: 44)
        doneButton.tintColor = UIColor.blue
        
        toolBar.setItems([spaceButton,doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        musicTextField.inputAccessoryView = toolBar
    }
    
    @objc private func dismissPickerView(){
        musicTextField.resignFirstResponder()
    }
    
    @IBAction func toDatePicker(_ sender: UIButton) {
         delegate?.chooseDate()
    }
    
    @IBAction func checkout(_ sender: UIButton) {
        delegate?.toPayment()
    }
    
    @IBAction func decreaseMin(_ sender: UIButton) {
        if  Int(minLabel.text!)! >= Int(1){
            min -= 1
            minLabel.text = String(describing: min)
            priceLabel.textColor = GroupreelColor.blingGreen
            priceLabel.text = "$" + String(format: "%.2f", (Double(hourLabel.text!)!*60 + Double(minLabel.text!)!)*Double(unit)!)
            self.price = priceLabel.text
        }
        if (priceLabel.text?.contains("$0"))!{
            priceLabel.textColor = UIColor.lightGray
            priceLabel.text = "$0.00"
        }
        let total = 3600 * hour + 60 * min
        delegate?.shouldUpdate(duration: total)
    }
    
    @IBAction func increaseMin(_ sender: UIButton) {
        min += 1
        minLabel.text = String(describing: min)
        priceLabel.textColor = GroupreelColor.blingGreen
        priceLabel.text = "$" + String(format: "%.2f", (Double(hourLabel.text!)!*60 + Double(minLabel.text!)!)*Double(unit)!)
        self.price = priceLabel.text
        let total = 3600 * hour + 60 * min
        delegate?.shouldUpdate(duration: total)
    }
    
    @IBAction func decreaseHour(_ sender: UIButton) {
        if Int(hourLabel.text!)! >= Int(1){
            hour -= 1
            hourLabel.text = String(describing: hour)
            priceLabel.textColor  = GroupreelColor.blingGreen
            priceLabel.text = "$" + String(format: "%.2f", (Double(hourLabel.text!)!*60 + Double(minLabel.text!)!)*Double(unit)!)
            self.price = priceLabel.text
        }
        if (priceLabel.text?.contains("$0"))!{
            priceLabel.textColor = UIColor.lightGray
            priceLabel.text = "$0.00"
        }
        
        let total = 3600 * hour + 60 * min
        delegate?.shouldUpdate(duration: total)
    }
    
    @IBAction func increaseHour(_ sender: UIButton) {
        hour += 1
        hourLabel.text = String(describing: hour)
        priceLabel.textColor = GroupreelColor.blingGreen
        priceLabel.text = "$" + String(format: "%.2f", (Double(hourLabel.text!)!*60 + Double(minLabel.text!)!)*Double(unit)!)
        self.price = priceLabel.text
        let total = 3600 * hour + 60 * min
        delegate?.shouldUpdate(duration: total)
    }
}

extension CreateEventCell:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if eventNameTF.text != ""{
            delegate?.shouldUpdate(name: eventNameTF.text!)
            musicTextField.text = "Choose Genre"
        }
        textField.resignFirstResponder()
        if codeTF.text == ""{
            codeTF.text = "Enter Promo Code"
        }else{
            let request = PriceRequest(duration: Int(hourLabel.text!)!*60 + Int(minLabel.text!)!, promo: codeTF.text!)
            WebServiceHandler().send(r: request, completion: { (success, response, error) in
                if success {
                    DispatchQueue.main.async {
                        if response!.savings == 0 {
                            self.codeTF.text = ""
                        }
                        self.priceLabel.text = "$" + String(format: "%.2f",response!.price)
                    }
                }else if let e = response?.error{
                    print(e)
                }else if let e = error {
                    print(e)
                }
            })
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == eventNameTF{
            delegate?.shouldUpdate(name: eventNameTF.text!)
        }
        
        if musicTextField.text == ""{
            musicTextField.text = pickerData[musicPicker.selectedRow(inComponent: 0)]
        }else{
           delegate?.update(music: musicTextField.text!)
        }

        if textField == noteTF{
            delegate?.updateNote(note: noteTF.text!)
        }
    }
}

extension CreateEventCell:UIPickerViewDataSource, UIPickerViewDelegate{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
}

