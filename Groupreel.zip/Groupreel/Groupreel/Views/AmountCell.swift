//
//  AmountCell.swift
//  Groupreel
//
//  Created by Lynn on 12/7/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class AmountCell: UITableViewCell {
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var errorBottomLine: UIView!
    @IBOutlet weak var errorView: UIView!
    @IBOutlet weak var errorImage: UIImageView!
    @IBOutlet weak var codeTextField: UITextField!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var minLabel: UILabel!
    @IBOutlet weak var minIncreaseBtn: UIButton!
    @IBOutlet weak var minDecreaseBtn: UIButton!
    @IBOutlet weak var hourLabel: UILabel!
    @IBOutlet weak var hourIncreaseBtn: UIButton!
    @IBOutlet weak var hourDecreaseBtn: UIButton!
    @IBOutlet weak var unitLabel: UILabel!
    
    var price:String!
    var unit:String = "5"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        UISetup()
        layer.cornerRadius = 5
    }
    
    override func layoutSubviews() {
        unitLabel.text = "$\(unit)/min"
    }
    
    private func UISetup() {
        minDecreaseBtn.setImage(IonIcons.image(withIcon: ion_ios_minus_outline, iconColor: GroupreelColor.blingGreen, iconSize: 20, imageSize: CGSize(width: 20, height: 20)), for: .normal)
        hourDecreaseBtn.setImage(IonIcons.image(withIcon: ion_ios_minus_outline, iconColor: GroupreelColor.blingGreen, iconSize: 20, imageSize: CGSize(width: 20, height: 20)), for: .normal)
        minIncreaseBtn.setImage(IonIcons.image(withIcon: ion_ios_plus_outline, iconColor: GroupreelColor.blingGreen, iconSize: 20, imageSize: CGSize(width: 20, height: 20)), for: .normal)
        hourIncreaseBtn.setImage(IonIcons.image(withIcon: ion_ios_plus_outline, iconColor: GroupreelColor.blingGreen, iconSize: 20, imageSize: CGSize(width: 20, height: 20)), for: .normal)
        errorImage.image = GroupreelImage.errorImage
        errorBottomLine.tintColor = GroupreelColor.errorColor
        errorLabel.textColor = GroupreelColor.errorColor
    }
    
    @IBAction func increaseMin(_ sender: UIButton) {
        var min:Int = Int(minLabel.text!)!
        min += 1
        minLabel.text = String(describing: min)
        priceLabel.textColor = GroupreelColor.blingGreen
        priceLabel.text = "$" + String(format: "%.2f", (Double(hourLabel.text!)!*60 + Double(minLabel.text!)!)*Double(unit)!)
        self.price = priceLabel.text
    }
    
    @IBAction func decreaseMin(_ sender: UIButton) {
        var min:Int = Int(minLabel.text!)!
        if  Int(minLabel.text!)! >= Int(1){
            min -= 1
            minLabel.text = String(describing: min)
            priceLabel.textColor = GroupreelColor.blingGreen
            priceLabel.text = "$" + String(format: "%.2f", (Double(hourLabel.text!)!*60 + Double(minLabel.text!)!)*Double(unit)!)
            self.price = priceLabel.text
        }
        if (priceLabel.text?.contains("$0"))!{
            priceLabel.textColor = UIColor.lightGray
            priceLabel.text = "$0.00"
        }
    }
    
    @IBAction func increaseHour(_ sender: UIButton) {
        var hour:Int = Int(hourLabel.text!)!
        hour += 1
        hourLabel.text = String(describing: hour)
        priceLabel.textColor = GroupreelColor.blingGreen
        priceLabel.text = "$" + String(format: "%.2f", (Double(hourLabel.text!)!*60 + Double(minLabel.text!)!)*Double(unit)!)
        self.price = priceLabel.text
    }
    
    @IBAction func decreaseHour(_ sender: UIButton) {
        var hour:Int = Int(hourLabel.text!)!
        if Int(hourLabel.text!)! >= Int(1){
            hour -= 1
            hourLabel.text = String(describing: hour)
            priceLabel.textColor  = GroupreelColor.blingGreen
            priceLabel.text = "$" + String(format: "%.2f", (Double(hourLabel.text!)!*60 + Double(minLabel.text!)!)*Double(unit)!)
            self.price = priceLabel.text
        }
        if (priceLabel.text?.contains("$0"))!{
            priceLabel.textColor = UIColor.lightGray
            priceLabel.text = "$0.00"
        }
    }
}

extension AmountCell:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        codeTextField.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if textField.text == ""{
            textField.text = "Enter Promo Code"
        }else{
            let request = PriceRequest(duration: Int(hourLabel.text!)!*60 + Int(minLabel.text!)!, promo: textField.text!)
            WebServiceHandler().send(r: request, completion: { (success, response, error) in
                if success {
                    DispatchQueue.main.async {
                        if response!.savings == 0 {
                            textField.text = ""
                        }
                        self.priceLabel.text = "$" + String(format: "%.2f",response!.price)
                    }
                }else if let e = response?.error{
                    print(e)
                }else if let e = error {
                    print(e)
                }
            })
        }
        return true
    }
}
