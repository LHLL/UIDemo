//
//  TimeCell.swift
//  Groupreel
//
//  Created by Lynn on 11/3/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class TimeCell: UITableViewCell {

    @IBOutlet weak var divider: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        divider.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi/4));
    }
    
}
