//
//  TimeCell.swift
//  Groupreel
//
//  Created by Lynn on 11/3/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class TimeCell: UITableViewCell {

    @IBOutlet weak var endTime: UILabel!
    @IBOutlet weak var startTime: UILabel!
    @IBOutlet weak var divider: UIView!
    @IBOutlet weak var statusLabel: UILabel!
    
    var event:Event!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        layer.cornerRadius = 10
        layer.masksToBounds = true
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d,yyyy h:mm a"
        dateFormatter.calendar = NSCalendar.current
        dateFormatter.timeZone = TimeZone.current
        Invigilator.shared.readyToShoot = {
            if dateFormatter.date(from: self.event.start!)!.isInTheFuture || dateFormatter.date(from: self.event.ends!)!.isInThePast{
                self.statusLabel.shake()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                    Invigilator.shared.errorHandler?("Not An Active Event","Your event is not active yet.")
                })
                return false
            }else{
                return true
            }
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        divider.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi/4));
    }
    
}
