//
//  ScheduleCell.swift
//  Groupreel
//
//  Created by Lynn on 12/7/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit
protocol ScheduleCellDelegate:class {
    func chooseDate()
}

class ScheduleCell: UITableViewCell {
    
    @IBOutlet weak var seprator: UIView!
    @IBOutlet weak var endDate: UILabel!
    @IBOutlet weak var startDate: UILabel!
    @IBOutlet weak var timeView: UIView!
    @IBOutlet weak var trigger: UIButton!
    
    weak var delegate:ScheduleCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        layer.cornerRadius = 5
        seprator.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi/4));
        
    }
    
    @IBAction func toDatePicker(_ sender: UIButton) {
        delegate?.chooseDate()
    }
    
}

