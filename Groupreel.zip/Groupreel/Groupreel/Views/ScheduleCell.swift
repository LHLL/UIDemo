//
//  ScheduleCell.swift
//  Groupreel
//
//  Created by Lynn on 12/7/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit
protocol ScheduleCellDelegate:class {
    func chooseDate()
    
//    func showChosenDate()
}

class ScheduleCell: UITableViewCell {
    @IBOutlet weak var seprator: UIView!
    @IBOutlet weak var endTime: UILabel!
    @IBOutlet weak var startTime: UILabel!
    @IBOutlet weak var endDate: UILabel!
    @IBOutlet weak var startDate: UILabel!
    @IBOutlet weak var timeView: UIView!
    @IBOutlet weak var errorView: UIView!
    @IBOutlet weak var errorImage: UIImageView!
    @IBOutlet weak var startTextField: UITextField!

    weak var delegate:ScheduleCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        layer.cornerRadius = 5
        errorImage.image = GroupreelImage.errorImage
        seprator.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi/4));
        if startTextField.text == ""{
            timeView.isHidden = false
//            delegate?.showChosenDate()
        }
    }
    
}

extension ScheduleCell:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        errorImage.isHidden = true
        errorView.isHidden = true
        startTextField.text = ""
        delegate?.chooseDate()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if startTextField.text == ""{
            errorImage.isHidden = false
            errorView.isHidden = false
            errorView.tintColor = GroupreelColor.errorColor
            startTextField.text = "     Choose a date and time."
            startTextField.textColor = GroupreelColor.errorColor
        }
        textField.resignFirstResponder()
        return true
    }
}

