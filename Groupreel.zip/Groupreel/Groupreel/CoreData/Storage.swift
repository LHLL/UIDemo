//
//  Storage.swift
//  Groupreel
//
//  Created by Xu, Jay on 2/8/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import Foundation
import CoreData

class Storage:NSObject{
    
    static var shared = Storage()
    
    var setting:Setting{
        return fetchSetting()
    }
    
    private var queue = DispatchQueue(label: "DataBaseQueue")
    private lazy var container:NSPersistentContainer = {
        let c = NSPersistentContainer(name: "GroupreelModel")
        c.loadPersistentStores(completionHandler: { (des, error) in})
        return c
    }()
    private lazy var context = container.viewContext
    private var ob:NSKeyValueObservation!
    private override init(){
        super.init()
        ob = setting.observe(\.bioEnabled, changeHandler: { (storage, change) in
            self.save()
        })
    }
    
    func fetchNews()->[News]?{
        let request = NSFetchRequest<News>(entityName: "News")
        do{
            return try context.fetch(request)
        }catch{
            print("Hi")
        }
        return nil
    }
    
    private func fetchSetting()->Setting{
        let request = NSFetchRequest<Setting>(entityName: "Setting")
        do{
            let settings = try context.fetch(request)
            if let setting = settings.first {
                return setting
            }else{
                return initSetting()
            }
        }catch{
            print("cannot fetching setting")
        }
        return initSetting()
    }
    
    private func initSetting()->Setting{
        let entity = NSEntityDescription.entity(forEntityName: "Setting",
                                                in: context)
        let setting = NSManagedObject(entity: entity!,
                                      insertInto: context) as! Setting
        setting.bioEnabled = false
        save()
        return setting
    }
    
    private func save(){
        guard context.hasChanges else{return}
        queue.sync {
            do{
                try context.save()
            }catch {
                print("fuck you")
            }
        }
    }
}
