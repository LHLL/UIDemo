//
//  SignupViewController.swift
//  Groupreel
//
//  Created by Lynn on 11/30/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {
    
    @IBOutlet weak var signInBtn: UIButton!
    @IBOutlet weak var signUpBtn: TransitionButton!
    @IBOutlet weak var confirmImage: UIImageView!
    @IBOutlet weak var passwordImage: UIImageView!
    @IBOutlet weak var phoneImage: UIImageView!
    @IBOutlet weak var emailImage: UIImageView!
    @IBOutlet weak var lastNameImage: UIImageView!
    @IBOutlet weak var firstNameImage: UIImageView!
    @IBOutlet weak var confirmTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var passwordTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var phoneTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var emailTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var lastNameTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var firstNameTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var container: UIView!
    
    private var gradientLayer: CAGradientLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = false
        uiSetUp()
    }
    
    private func uiSetUp() {
        signUpBtn.layer.cornerRadius = signUpBtn.frame.size.height / 2
        signInBtn.setTitleColor(UIColor(displayP3Red: 76/25500,
                                        green: 197/255.0,
                                        blue: 106/255.0,
                                        alpha: 1),
                                for: .normal)
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.shared.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
        
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = signUpBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.cornerRadius = signUpBtn.frame.size.height / 2
        signUpBtn.layer.insertSublayer(gradientLayer, at: 0)
        signUpBtn.layer.masksToBounds = true
        
        container.layer.cornerRadius = 5
        
        let att = [NSAttributedStringKey.foregroundColor: GroupreelColor.tfBlue,
                   NSAttributedStringKey.font:UIFont.systemFont(ofSize: 20, weight: .bold)]
        firstNameTextField.attributedPlaceholder = NSAttributedString(string: "First Name", attributes: att)
        lastNameTextField.attributedPlaceholder = NSAttributedString(string: "Last Name", attributes: att)
        emailTextField.attributedPlaceholder = NSAttributedString(string: "Email", attributes: att)
        phoneTextField.attributedPlaceholder = NSAttributedString(string: "Phone", attributes: att)
        passwordTextField.attributedPlaceholder = NSAttributedString(string: "Password", attributes: att)
        confirmTextField.attributedPlaceholder = NSAttributedString(string: "Confirm Password", attributes: att)
        
        showTitle()
        
        firstNameImage.image = GroupreelImage.shared.checkImg
        lastNameImage.image = GroupreelImage.shared.checkImg
        emailImage.image = GroupreelImage.shared.checkImg
        phoneImage.image = GroupreelImage.shared.checkImg
        passwordImage.image = GroupreelImage.shared.checkImg
        confirmImage.image = GroupreelImage.shared.checkImg
    }

    @IBAction func signIn(_ sender: UIButton) {
        let story = UIStoryboard.init(name: "Main", bundle: nil)
        let toLogin = story.instantiateViewController(withIdentifier: "SIVC")
        navigationController?.pushViewController(toLogin, animated: true)
    }
    
    @IBAction func signUp(_ sender: TransitionButton) {
        sender.startAnimation()
        sender.isEnabled = false
        let request = RegistrationRequest(name: emailTextField.text!,
                                          pass: passwordTextField.text!,
                                          first: firstNameTextField.text!,
                                          last: lastNameTextField.text!,
                                          phone: phoneTextField.text!)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                guard let r = response else{return}
                guard r.activated else{return}
                DispatchQueue.main.async {
                    sender.isEnabled = true
                    sender.stopAnimation(animationStyle: .expand, completion: {
                        let story = UIStoryboard.init(name: "Main", bundle: nil)
                        let toLogin = story.instantiateViewController(withIdentifier: "SIVC")
                        self.navigationController?.pushViewController(toLogin, animated: false)
                    })
                }
            }else if let e = response?.error{
                sender.stopAnimation(animationStyle: .shake, completion: {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                        self.showAlert(with: "Cannot Create User", and: e.description)
                        sender.isEnabled = true
                    })
                })
            }else if let e = error{
                sender.stopAnimation(animationStyle: .shake, completion: {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                        self.showAlert(with: "Cannot Create User", and: e.description)
                        sender.isEnabled = true
                    })
                })
            }
        }
    }
    
    override func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }
}

extension SignupViewController:UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == firstNameTextField{
            firstNameImage.isHidden = true
            firstNameTextField.errorMessage = nil
        }else if textField == lastNameTextField{
            lastNameImage.isHidden = true
            lastNameTextField.errorMessage = nil
        }else if textField == emailTextField{
            emailImage.isHidden = true
            emailTextField.errorMessage = nil
        }else if textField == phoneTextField{
            phoneImage.isHidden = true
            phoneTextField.errorMessage = nil
        }else if textField == passwordTextField{
            passwordTextField.errorMessage = nil
            passwordTextField.isSecureTextEntry = true
            passwordImage.isHidden = true
        }else{
            confirmTextField.errorMessage = nil
            confirmImage.isHidden = true
            confirmTextField.isSecureTextEntry = true
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let tf = textField as? SkyFloatingLabelTextField{
            tf.errorMessage = nil
        }
        if textField == phoneTextField {
            let newString = NSString(string: textField.text!).replacingCharacters(in: range, with: string)
            guard validPhoneLenth(string: newString) else {
                return false
            }
            // Add Hyphen
            let originalString = NSString(string: textField.text!).replacingCharacters(in: range, with: string)
            let finalString = originalString.replacingOccurrences(of: "-", with: "")
            
            // Typing new character - Add Hypen after 3rd and 7th character
            if range.length == 0 {
                if ( range.location == 3 || range.location == 7) && !finalString.contains("-") {
                    textField.text = "\(textField.text!)-\(string)"
                    return false
                }
            }
                // Delete character - delete hyphen when deleting its trailing digit
            else if range.length == 1 {
                if range.location == 4 || range.location == 8 {
                    
                    textField.text = String(originalString[...originalString.index(before: originalString.endIndex)])
                    return false
                }
                else if range.location < finalString.count {
                    // Don't allow user to delete character in between
                    return false
                }
            }
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == firstNameTextField{
            if firstNameTextField.text != ""{
                lastNameTextField.isEnabled = true
                lastNameTextField.becomeFirstResponder()
                firstNameImage.isHidden = false
            }else{
                firstNameTextField.errorMessage = "First name is mandatory"
                firstNameTextField.shake()
                Utility.vibrate()
            }
        }else if textField == lastNameTextField{
            if lastNameTextField.text != ""{
                emailTextField.isEnabled = true
                emailTextField.becomeFirstResponder()
                lastNameImage.isHidden = false
            }else{
                lastNameTextField.errorMessage = "Last name is mandatory"
                lastNameTextField.shake()
                Utility.vibrate()
            }
        }else if textField == emailTextField{
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
            let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            if emailTest.evaluate(with: textField.text){
                phoneTextField.isEnabled = true
                phoneTextField.becomeFirstResponder()
                emailImage.isHidden = false
            }else{
                emailTextField.shake()
                Utility.vibrate()
                emailTextField.text = ""
                emailTextField.errorMessage = "Invalid email address!"
                return false
            }
        }else if textField == phoneTextField{
            if phoneTextField.text != "" {
                passwordTextField.isEnabled = true
                passwordTextField.becomeFirstResponder()
                passwordImage.isHidden = false
            }else{
                phoneTextField.errorMessage = "Phone number is mandatory"
                phoneTextField.shake()
                Utility.vibrate()
            }
        }else if textField == passwordTextField{
            if passwordTextField.text != "" {
                confirmTextField.isEnabled = true
                confirmTextField.becomeFirstResponder()
                passwordImage.isHidden = false
            }else{
                passwordTextField.errorMessage = "Password is mandatory"
                passwordTextField.shake()
                Utility.vibrate()
            }
        }else{
            if confirmTextField.text != ""{
                if confirmTextField.text == passwordTextField.text{
                    textField.resignFirstResponder()
                    confirmImage.isHidden = false
                }else{
                    confirmTextField.errorMessage = "Passwords you entered are different"
                    confirmTextField.shake()
                    Utility.vibrate()
                    confirmTextField.text = ""
                }
            }
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        if textField == phoneTextField{
            if textField.text?.count == 12{
                passwordTextField.isEnabled = true
                passwordTextField.becomeFirstResponder()
                phoneImage.isHidden = false
            }else{
                phoneTextField.errorMessage = "Invalid phone number!"
                Utility.vibrate()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: {
                    self.phoneTextField.becomeFirstResponder()
                })
            }
        }
    }
    
    func validPhoneLenth(string : String) -> Bool {
        let finalString = string.replacingOccurrences(of: "-", with: "")
        if finalString.count > 10 {
            return false
        }
        return true
    }
}
