//
//  FootageViewController.swift
//  Groupreel
//
//  Created by Lynn on 1/17/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class FootageViewController: UIViewController {
    @IBOutlet weak var settingBtn: UIButton!
    @IBOutlet weak var manageBtn: UIButton!
    @IBOutlet weak var cameraBtn: UIButton!
    @IBOutlet weak var eventBtn: UIButton!
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var footageTableView: UITableView!
    private var price:String?
    
    private var gradientLayer: CAGradientLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
        backgroundView.backgroundColor = GroupreelColor.backColor
        footageTableView.layer.cornerRadius = 5
        footageTableView.register( UINib(nibName: "AmountCell", bundle: nil), forCellReuseIdentifier: "AmountCell")
    }
    
    override func viewDidLayoutSubviews() {
        //gradient color
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = saveBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        saveBtn.layer.insertSublayer(gradientLayer, at: 0)
        saveBtn.layer.masksToBounds = true
    }
    
    private func UISetup() {
        saveBtn.layer.cornerRadius = saveBtn.frame.size.height / 2
        gradientView.layer.cornerRadius = saveBtn.frame.size.height / 2
        
        //tabBarViewImage setup
        cameraBtn.layer.borderWidth = 4
        cameraBtn.layer.borderColor = UIColor.white.cgColor
        cameraBtn.layer.cornerRadius = cameraBtn.frame.size.height / 2
        
        homeBtn.setImage(GroupreelImage.shared.homeImage, for: .normal)
        eventBtn.setImage(GroupreelImage.shared.eventImage, for: .normal)
        manageBtn.setImage(GroupreelImage.shared.MessageImage, for: .normal)
        settingBtn.setImage(GroupreelImage.shared.SettingImage, for: .normal)
        cameraBtn.setImage(GroupreelImage.shared.cameraImage, for: .normal)
        
        navigationItem.leftBarButtonItem?.image = IonIcons.image(withIcon: ion_chevron_left,
                                                                 iconColor: UIColor.white,
                                                                 iconSize: 30,
                                                                 imageSize: CGSize(width: 30, height: 30))
        navigationItem.leftBarButtonItem = nil
        navigationItem.leftBarButtonItem?.isEnabled = false
        showTitle()
    }
    
    @IBAction func saveFootage(_ sender: UIButton) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toDate = story.instantiateViewController(withIdentifier: "EventVC")
        navigationController?.pushViewController(toDate, animated: true)
    }
    
//    @objc
//    private func goBack(){
//        navigationController?.popToRootViewController(animated: true)
//    }
}

extension FootageViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell?
        cell = tableView.dequeueReusableCell(withIdentifier: "AmountCell", for: indexPath)
//        (cell as! AmountCell).unit = self.price!
        return cell!
    }
}
    

extension FootageViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 228
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}

