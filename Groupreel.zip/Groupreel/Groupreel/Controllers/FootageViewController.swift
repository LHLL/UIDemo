//
//  FootageViewController.swift
//  Groupreel
//
//  Created by Lynn on 1/17/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class FootageViewController: UIViewController {
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var footageTableView: UITableView!
    
    private var gradientLayer: CAGradientLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
        backgroundView.backgroundColor = GroupreelColor.backColor
        footageTableView.layer.cornerRadius = 5
        footageTableView.register( UINib(nibName: "AmountCell", bundle: nil), forCellReuseIdentifier: "AmountCell")
    }
    
    override func viewDidLayoutSubviews() {
        //gradient color
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = saveBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        saveBtn.layer.insertSublayer(gradientLayer, at: 0)
        saveBtn.layer.masksToBounds = true
    }
    
    private func UISetup() {
        saveBtn.layer.cornerRadius = saveBtn.frame.size.height / 2
        gradientView.layer.cornerRadius = saveBtn.frame.size.height / 2
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.shared.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
        showTitle()
    }
    
    @IBAction func saveFootage(_ sender: UIButton) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toDate = story.instantiateViewController(withIdentifier: "EventVC")
        navigationController?.pushViewController(toDate, animated: true)
    }
    
}

extension FootageViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AmountCell", for: indexPath)
        (cell as! AmountCell).unit = String(format: "%.2f", Cache.price)
        return cell
    }
}
    

extension FootageViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 228
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}

