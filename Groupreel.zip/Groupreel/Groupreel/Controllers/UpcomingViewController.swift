//
//  UpcomingViewController.swift
//  Groupreel
//
//  Created by Lynn on 1/10/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class UpcomingViewController: UIViewController {
    @IBOutlet weak var cameraBtn: UIButton!
    @IBOutlet weak var settingBtn: UIButton!
    @IBOutlet weak var manageBtn: UIButton!
    @IBOutlet weak var eventBtn: UIButton!
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var eventTableView: UITableView!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var backgroundView: UIView!
    private var events:[Event] = []
    private let currentDate = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
        eventTableView.register(UINib(nibName: "EventCell", bundle: nil), forCellReuseIdentifier: "EventCell")
    }

    @IBAction func filteTime(_ sender: UISegmentedControl) {
    }
    
    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        navigationItem.leftBarButtonItem?.image = IonIcons.image(withIcon: ion_chevron_left,
                                                                 iconColor: UIColor.white,
                                                                 iconSize: 30,
                                                                 imageSize: CGSize(width: 30, height: 30))
        
        
        //tabBarViewImage setup
        cameraBtn.layer.borderWidth = 4
        cameraBtn.layer.borderColor = UIColor.white.cgColor
        cameraBtn.layer.cornerRadius = cameraBtn.frame.size.height / 2
        
        homeBtn.setImage(GroupreelImage.homeImage, for: .normal)
        eventBtn.setImage(GroupreelImage.eventImage, for: .normal)
        manageBtn.setImage(GroupreelImage.MessageImage, for: .normal)
        settingBtn.setImage(GroupreelImage.SettingImage, for: .normal)
        cameraBtn.setImage(GroupreelImage.cameraImage, for: .normal)
    }
    
    @objc
    private func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }
}

extension UpcomingViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventCell", for: indexPath)
        let dateFormatter = DateFormatter()
        if dateFormatter.date(from: events[indexPath.row].start)! == currentDate {
            (cell as! EventCell).header.text = "HAPPENING NOW"
            (cell as! EventCell).eventTitle.text = events[indexPath.row].name
            (cell as! EventCell).startTime.text = events[indexPath.row].startTime
            (cell as! EventCell).endTime.text = events[indexPath.row].endTime
            (cell as! EventCell).startDate.text = events[indexPath.row].start
            (cell as! EventCell).endDate.text = events[indexPath.row].ends
            (cell as! EventCell).header.textColor = GroupreelColor.blingGreen
        }else if dateFormatter.date(from: events[indexPath.row].start)! > currentDate {
            (cell as! EventCell).header.text = "STARTS IN 298 DAYS"
            (cell as! EventCell).eventTitle.text = events[indexPath.row].name
            (cell as! EventCell).startTime.text = events[indexPath.row].startTime
            (cell as! EventCell).endTime.text = events[indexPath.row].endTime
            (cell as! EventCell).startDate.text = events[indexPath.row].start
            (cell as! EventCell).endDate.text = events[indexPath.row].ends
            (cell as! EventCell).header.textColor = UIColor.lightGray
        }else if dateFormatter.date(from: events[indexPath.row].start)! < currentDate {
            self.segmentController.selectedSegmentIndex = 1
            (cell as! EventCell).header.text = "Intraspire Retreat"
            (cell as! EventCell).eventTitle.text = events[indexPath.row].name
            (cell as! EventCell).startTime.text = events[indexPath.row].startTime
            (cell as! EventCell).endTime.text = events[indexPath.row].endTime
            (cell as! EventCell).startDate.text = events[indexPath.row].start
            (cell as! EventCell).endDate.text = events[indexPath.row].ends
            (cell as! EventCell).header.textColor = UIColor.darkText
        }
        return cell
    }
}

extension UpcomingViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 142
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = UIColor.clear
        return v
    }
}
