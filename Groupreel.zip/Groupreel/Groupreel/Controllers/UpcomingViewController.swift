//
//  UpcomingViewController.swift
//  Groupreel
//
//  Created by Lynn on 1/10/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class UpcomingViewController: CustomTransitionViewController {
    
    @IBOutlet weak var eventTableView: UITableView!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var backgroundView: UIView!
    
    var events:[Event] = []
    private let currentDate = Date()
    private var data:[Event] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
        showTitle()
        eventTableView.register(UINib(nibName: "EventCell", bundle: nil), forCellReuseIdentifier: "EventCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d,yyyy h:mm a"
        if segmentController.selectedSegmentIndex == 0 {
            eventTableView.allowsSelection = true
            data = events.filter{
                dateFormatter.date(from: $0.start)!.isInToday || dateFormatter.date(from: $0.start)!.isInTheFuture
                
            }
        }else{
            data = events.filter{
                dateFormatter.date(from: $0.ends)!.isInThePast
            }
        }
        eventTableView.reloadData()
    }
    
    override func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func filteTime(_ sender: UISegmentedControl) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d,yyyy h:mm a"
        if segmentController.selectedSegmentIndex == 0 {
            data = events.filter{
                dateFormatter.date(from: $0.start)!.isInToday || dateFormatter.date(from: $0.start)!.isInTheFuture
            }
        }else{
            data = events.filter{
                dateFormatter.date(from: $0.ends)!.isInThePast
            }
        }
        eventTableView.reloadData()
    }
    
    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        navigationItem.leftBarButtonItem?.image = IonIcons.image(withIcon: ion_chevron_left,
                                                                 iconColor: UIColor.white,
                                                                 iconSize: 30,
                                                                 imageSize: CGSize(width: 30, height: 30))
    }
}

extension UpcomingViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventCell", for: indexPath) as! EventCell
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM dd,yyyy h:mm a"
        let start = dateFormatter.date(from: data[indexPath.section].start)
        let end = dateFormatter.date(from: data[indexPath.section].ends)
        dateFormatter.dateFormat = "MMM d, yyyy ?h:mm a"
        var eventStart = dateFormatter.string(from: start!)
        eventStart = eventStart.replacingOccurrences(of: "?", with: "\n")
        var eventEnd = dateFormatter.string(from: end!)
        eventEnd = eventEnd.replacingOccurrences(of: "?", with: "\n")
        //        cell.shouldHide = start!.isInThePast
        var text = "HAPPENING NOW"
        
        if start!.isInToday {
            text = "HAPPENING NOW"
        }
        
        if start!.isInTheFuture {
            let calendar = NSCalendar.current
            let date1 = calendar.startOfDay(for: start!)
            let date2 = calendar.startOfDay(for: Date())
            
            let components = calendar.dateComponents([.day], from: date2, to: date1)
            text = "START IN \(components.day!) DAYS"
        }
        
        if end!.isInThePast {
            text = "Intraspire Retreat"
        }
        
        cell.header.text = text
        cell.eventTitle.text = data[indexPath.section].name
        cell.startTime.text = eventStart
        cell.endTime.text = eventEnd
        cell.header.textColor = text == "HAPPENING NOW" ? GroupreelColor.blingGreen : .darkGray
        return cell
    }
}

extension UpcomingViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 142
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = UIColor.clear
        return v
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if segmentController.selectedSegmentIndex == 0{
            let story = UIStoryboard.init(name: "Main", bundle: nil)
            let controller = story.instantiateViewController(withIdentifier: "BVC")
            (controller as! BashViewController).event = data[indexPath.row]
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if segmentController.selectedSegmentIndex == 1{
            eventTableView.deselectRow(at: indexPath, animated: true)
        }
    }
}
