//
//  SigninViewController.swift
//  Groupreel
//
//  Created by Lynn on 11/30/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class SigninViewController: UIViewController {
    
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var signBtn: UIButton!
    @IBOutlet weak var passwordTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var emailTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var container: UIView!
    
    private var gradientLayer: CAGradientLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        uiSetup()
    }
    
    private func uiSetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        signBtn.layer.cornerRadius = signBtn.frame.size.height / 2
        signUpBtn.setTitleColor(UIColor(displayP3Red: 76/25500, green: 197/255.0, blue: 106/255.0, alpha: 1), for: .normal)
        
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = signBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        signBtn.layer.addSublayer(gradientLayer)
        signBtn.layer.masksToBounds = true
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
        navigationController?.navigationBar.isHidden = false
        showTitle()
        
        let att = [NSAttributedStringKey.foregroundColor: GroupreelColor.tfBlue,
                   NSAttributedStringKey.font:UIFont.systemFont(ofSize: 20, weight: .bold)]
        emailTextField.attributedPlaceholder = NSAttributedString(string: "Email", attributes: att)
        passwordTextField.attributedPlaceholder = NSAttributedString(string: "Password", attributes: att)
    }

    @IBAction func signUp(_ sender: UIButton) {
        let story = UIStoryboard.init(name: "Main", bundle: nil)
        let toSignUp = story.instantiateViewController(withIdentifier: "SUVC")
        navigationController?.pushViewController(toSignUp, animated: true)
    }
    
    @IBAction func signIn(_ sender: UIButton) {
        guard emailTextField.text != "" else{
            emailTextField.shake()
            Utility.vibrate()
            return
        }
        guard passwordTextField.text != "" else{
            passwordTextField.shake()
            Utility.vibrate()
            return
        }
        let request = AuthRequest(name: emailTextField.text!, pass: passwordTextField.text!)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                DispatchQueue.main.async {
                    let story = UIStoryboard.init(name: "Main", bundle: nil)
                    let toBashController = story.instantiateViewController(withIdentifier: "CEVC")
                    self.navigationController?.pushViewController(toBashController, animated: true)
                }
            }else if let e = response?.error{
                print(e)
            }else if let e = error {
                print(e)
            }
        }
    }
    
    @objc
    private func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }
}

extension SigninViewController:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == emailTextField{
            emailTextField.text = ""
        }else{
            passwordTextField.isSecureTextEntry = true
            passwordTextField.text = ""
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField{
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
            let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            if emailTest.evaluate(with: textField.text){
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: {
                    self.passwordTextField.becomeFirstResponder()
                })
            }else{
                Utility.vibrate()
                emailTextField.text = ""
                return false
            }
            if emailTextField.text != ""{
                passwordTextField.isEnabled = true
            }
        }else{
            textField.resignFirstResponder()
        }
        return true
    }
}

