//
//  SigninViewController.swift
//  Groupreel
//
//  Created by Lynn on 11/30/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class SigninViewController: CustomTransitionViewController {
    
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var signBtn: TransitionButton!
    @IBOutlet weak var passwordTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var emailTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var container: UIView!
    
    private var gradientLayer: CAGradientLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        uiSetup()
    }
    
    private func uiSetup() {
        signBtn.layer.cornerRadius = signBtn.frame.size.height / 2
        signUpBtn.setTitleColor(UIColor(displayP3Red: 76/25500, green: 197/255.0, blue: 106/255.0, alpha: 1), for: .normal)
        
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = signBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.cornerRadius = signBtn.frame.size.height / 2
        gradientLayer.masksToBounds = true
        signBtn.layer.insertSublayer(gradientLayer, at: 0)
        signBtn.layer.masksToBounds = true
        signBtn.spinnerColor = .white
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.shared.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
        navigationController?.navigationBar.isHidden = false
        showTitle()
        
        let att = [NSAttributedStringKey.foregroundColor: GroupreelColor.tfBlue,
                   NSAttributedStringKey.font:UIFont.systemFont(ofSize: 20, weight: .bold)]
        emailTextField.attributedPlaceholder = NSAttributedString(string: "Email", attributes: att)
        passwordTextField.attributedPlaceholder = NSAttributedString(string: "Password", attributes: att)
    }

    @IBAction func signUp(_ sender: UIButton) {
        let story = UIStoryboard.init(name: "Main", bundle: nil)
        let toSignUp = story.instantiateViewController(withIdentifier: "SUVC")
        navigationController?.pushViewController(toSignUp, animated: true)
    }
    
    @IBAction func signIn(_ sender: TransitionButton) {
        guard emailTextField.text != "" else{
            emailTextField.shake()
            emailTextField.errorMessage = "User name is mandatory!"
            Utility.vibrate()
            return
        }
        guard passwordTextField.text != "" else{
            passwordTextField.shake()
            passwordTextField.errorMessage = "Password is mandatory!"
            Utility.vibrate()
            return
        }
        sender.isEnabled = false
        sender.startAnimation()
        Cache.currentUser = emailTextField.text!
        let request = AuthRequest(name: emailTextField.text!, pass: passwordTextField.text!)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                self.fetchEvents(sender:sender)
            }else if let e = response?.error{
                Cache.currentUser = ""
                DispatchQueue.main.async(execute: { () -> Void in
                    sender.stopAnimation(animationStyle: .shake, completion: {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                            self.showAlert(with: "Authentication Failed", and: e.description)
                            sender.isEnabled = true
                        })
                    })
                })
            }else if let e = error {
                Cache.currentUser = ""
                DispatchQueue.main.async(execute: { () -> Void in
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                        self.showAlert(with: "Authentication Failed", and: e.description)
                        sender.isEnabled = true
                    })
                })
            }
        }
    }
    
    override func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }
    
    private func fetchEvents(sender:TransitionButton){
        let request = AllEventRequest(with: Cache.currentUser)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                DispatchQueue.main.async {
                    sender.isEnabled = true
                    sender.stopAnimation(animationStyle: .expand, completion: {
                        let tab = GRTabBarController.loadFromNib()
                        tab.events = response?.events ?? []
                        //self.navigationController?.pushViewController(toBashController, animated: false)
                        self.present(tab, animated: true, completion: nil)
                    })
                }
            }else if let e = response?.error{
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                    self.showAlert(with: "Network Error", and: e.description)
                    sender.isEnabled = true
                })
            }else if let e = error {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                    self.showAlert(with: "Network Error", and: e.description)
                    sender.isEnabled = true
                })
            }
        }
        let r = PriceRequest(duration: 1)
        WebServiceHandler().send(r: r) { (success, response, error) in
            Cache.price = response?.unit ?? 0
        }
    }
}

extension SigninViewController:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == emailTextField{
            emailTextField.text = ""
            emailTextField.errorMessage = nil
        }else{
            passwordTextField.isSecureTextEntry = true
            passwordTextField.text = ""
            passwordTextField.errorMessage = nil
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == emailTextField{
            emailTextField.errorMessage = nil
        }else{
            passwordTextField.errorMessage = nil
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField{
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
            let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            if emailTest.evaluate(with: textField.text){
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: {
                    self.passwordTextField.becomeFirstResponder()
                })
            }else{
                Utility.vibrate()
                emailTextField.text = ""
                emailTextField.errorMessage = "Invalid email address!"
                return false
            }
            if emailTextField.text != ""{
                passwordTextField.isEnabled = true
            }
        }else{
            textField.resignFirstResponder()
        }
        return true
    }
}

