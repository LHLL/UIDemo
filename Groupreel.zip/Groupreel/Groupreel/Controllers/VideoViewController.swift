//
//  ViewController.swift
//  CameraTest
//
//  Created by Xu, Jay on 2/1/18.
//  Copyright © 2018 wf. All rights reserved.
//

import UIKit
import AVFoundation
import Photos

class VideoViewController: UIViewController {

    @IBOutlet weak var previewView: UIView!
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var recordBtn: UIButton!
    @IBOutlet weak var playBtn: UIButton!
    
    private lazy var player:Player = {
        let player = Player()
        player.playbackDelegate = self
        player.view.frame = playerView.bounds
        return player
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCaptureSession()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        do{
            try NextLevel.shared.start()
        }catch let error {
            print(error)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setupCameraView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !playerView.subviews.contains(player.view){
            playerView.addSubview(player.view)
        }
        addChildViewController(player)
        player.didMove(toParentViewController: self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NextLevel.shared.stop()
    }
    
    private func setupCameraView(){
        guard previewView.layer.sublayers == nil else{
            guard !previewView.layer.sublayers!.contains(NextLevel.shared.previewLayer) else{
                return
            }
            NextLevel.shared.previewLayer.frame = previewView.bounds
            previewView.layer.addSublayer(NextLevel.shared.previewLayer)
            return
        }
        NextLevel.shared.previewLayer.frame = previewView.bounds
        previewView.layer.addSublayer(NextLevel.shared.previewLayer)
    }
    
    private func setupCaptureSession(){
        NextLevel.shared.delegate = self
        //NextLevel.shared.deviceDelegate = self
        NextLevel.shared.videoDelegate = self
        //NextLevel.shared.photoDelegate = self
        
        // modify .videoConfiguration, .audioConfiguration, .photoConfiguration properties
        // Compression, resolution, and maximum recording time options are available
        NextLevel.shared.videoConfiguration.maximumCaptureDuration = CMTimeMakeWithSeconds(10, 600)
        NextLevel.shared.audioConfiguration.bitRate = 44000
    }
    
    @IBAction func play(_ sender: UIButton) {
        self.player.playFromBeginning()
    }
    
    @IBAction func startRecording(_ sender: UIButton) {
        if NextLevel.shared.isRecording {
            //NextLevel.shared.capturePhotoFromVideo()
            NextLevel.shared.pause()
            sender.isHidden = false
        }else{
            NextLevel.shared.record()
        }
    }
}

extension VideoViewController:NextLevelDelegate {
    
    // session interruption
    func nextLevelSessionWasInterrupted(_ nextLevel: NextLevel){
        NextLevel.shared.pause()
    }
    
    func nextLevelSessionInterruptionEnded(_ nextLevel: NextLevel){
        NextLevel.shared.record()
    }
}

extension VideoViewController:NextLevelVideoDelegate{
    
    func nextLevel(_ nextLevel: NextLevel, didStartClipInSession session: NextLevelSession){
        print("start")
    }
    
    func nextLevel(_ nextLevel: NextLevel, didCompleteClip clip: NextLevelClip, inSession session: NextLevelSession){
        playerView.isHidden = false
        player.url = clip.url
        playBtn.isHidden = false
//        PHPhotoLibrary.shared().performChanges({
//            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: clip.url!)
//        }) { saved, error in
//            if saved {
//                let fetchOptions = PHFetchOptions()
//                fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
//
//                let fetchResult = PHAsset.fetchAssets(with: .video, options: fetchOptions).firstObject
//                print("saved")
//            }
//        }
    }
    
    func nextLevel(_ nextLevel: NextLevel, didCompletePhotoCaptureFromVideoFrame photoDict: [String : Any]?){
        print("here")
    }
}

extension VideoViewController:PlayerPlaybackDelegate{
    
    func playerPlaybackDidEnd(_ player: Player){
        playerView.isHidden = true
        previewView.isHidden = false
        recordBtn.isHidden = false
        playBtn.isHidden = true
    }
}

