//
//  ViewController.swift
//  CameraTest
//
//  Created by Xu, Jay on 2/1/18.
//  Copyright © 2018 wf. All rights reserved.
//

import UIKit
import AVFoundation
import Photos

class VideoViewController: UIViewController {

    @IBOutlet weak var previewView: UIView!
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var recordBtn: UIButton!
    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var exitBtn: UIButton!
    @IBOutlet weak var subBtn: UIButton!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var timeLabel: UILabel!
    
    private lazy var player:Player = {
        let player = Player()
        player.playbackDelegate = self
        player.view.frame = playerView.bounds
        return player
    }()
    
    private var recordTimer:Timer!
    private var ob:NSKeyValueObservation!
    private var duration = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCaptureSession()
        exitBtn.setImage(GroupreelImage.shared.exit,
                         for: .normal)
        ob = NextLevel.shared.observe(\._recording, changeHandler: { (flag, chagnes) in
            if flag._recording{
                DispatchQueue.main.async {
                    self.timeLabel.text = "00:00"
                    self.recordTimer = Timer.scheduledTimer(timeInterval: 1,
                                                            target: self,
                                                            selector: #selector(self.updateRecordingTime),
                                                            userInfo: nil,
                                                            repeats: true)
                }
            }else{
                self.recordTimer.invalidate()
            }
        })
        self.timeLabel.text = "00:00"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        do{
            try NextLevel.shared.start()
        }catch let error {
            self.showAlert(with: "Cannot Start Camera", and: error.localizedDescription)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setupCameraView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !playerView.subviews.contains(player.view){
            playerView.addSubview(player.view)
        }
        addChildViewController(player)
        player.didMove(toParentViewController: self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NextLevel.shared.stop()
    }
    
    private func setupCameraView(){
        guard previewView.layer.sublayers == nil else{
            guard !previewView.layer.sublayers!.contains(NextLevel.shared.previewLayer) else{
                return
            }
            NextLevel.shared.previewLayer.frame = previewView.bounds
            previewView.layer.addSublayer(NextLevel.shared.previewLayer)
            return
        }
        NextLevel.shared.previewLayer.frame = previewView.bounds
        previewView.layer.addSublayer(NextLevel.shared.previewLayer)
    }
    
    private func setupCaptureSession(){
        NextLevel.shared.delegate = self
        NextLevel.shared.videoDelegate = self
        NextLevel.shared.videoConfiguration.maximumCaptureDuration = CMTimeMakeWithSeconds(120, 600)
        NextLevel.shared.audioConfiguration.bitRate = 44000
    }
    
    @IBAction func play(_ sender: UIButton) {
        timeLabel.isHidden = true
        playBtn.isHidden = true
        subBtn.isHidden = true
        saveBtn.isHidden = true
        player.playFromBeginning()
    }
    
    @IBAction func saveToSystemAlbum(_ sender: UIButton) {
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: self.player.url!)
        }) { saved, error in
            if saved {
                DispatchQueue.main.async {
                    self.showAlert(with: "Video Clip Saved", and: "Your memory has been secured.")
                }
            }
        }
    }
    
    @IBAction func uploadToAWS(_ sender: UIButton) {
        playerView.isHidden = true
        previewView.isHidden = false
        recordBtn.isHidden = false
        playBtn.isHidden = true
        let id = "\(Cache.event)_\(Utility.generateRandomStr())"
        UploadManager.shared.uploadInBackground(with: player.url!,
                                                bucket: "groupreel/\(Cache.eventID)",
            and: id)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func startRecording(_ sender: UIButton) {
        if NextLevel.shared.isRecording {
            sender.setImage(UIImage(named:"record-button-not-recording"),
                            for: .normal)
            NextLevel.shared.pause()
            sender.isHidden = false
        }else{
            sender.setImage(UIImage(named:"record-button-recording"),
                            for: .normal)
            NextLevel.shared.record()
        }
    }
    
    @IBAction func dismissCameraView(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @objc
    private func updateRecordingTime(){
        let min = Int(duration / 60)
        let sec = Int(duration%60)
        let minStr = min < 10 ? "0\(min)" : "\(min)"
        let secStr = sec < 10 ? "0\(sec)" : "\(sec)"
        DispatchQueue.main.async {
            self.timeLabel.text = "\(minStr):\(secStr)"
        }
    }
}

extension VideoViewController:NextLevelDelegate {
    
    // session interruption
    func nextLevelSessionWasInterrupted(_ nextLevel: NextLevel){
        NextLevel.shared.pause()
    }
    
    func nextLevelSessionInterruptionEnded(_ nextLevel: NextLevel){
        NextLevel.shared.record()
    }
}

extension VideoViewController:NextLevelVideoDelegate{
    
    func nextLevel(_ nextLevel: NextLevel, didStartClipInSession session: NextLevelSession){
        print("start shooting video")
    }
    
    func nextLevel(_ nextLevel: NextLevel, didCompleteClip clip: NextLevelClip, inSession session: NextLevelSession){
        playerView.isHidden = false
        player.url = clip.url
        playBtn.isHidden = false
        subBtn.isHidden = false
        saveBtn.isHidden = false
    }
    
    func nextLevel(_ nextLevel: NextLevel, didCompletePhotoCaptureFromVideoFrame photoDict: [String : Any]?){
        print("photo captured")
    }
}

extension VideoViewController:PlayerPlaybackDelegate{
    
    func playerPlaybackDidEnd(_ player: Player){
        playBtn.isHidden = false
        subBtn.isHidden = false
        saveBtn.isHidden = false
        timeLabel.isHidden = false
    }
}

