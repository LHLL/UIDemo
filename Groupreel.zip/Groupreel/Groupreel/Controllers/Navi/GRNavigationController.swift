//
//  GRNavigationController.swift
//  Groupreel
//
//  Created by Xu, Jay on 2/7/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class GRNavigationController: UINavigationController {
    
    override func loadView() {
        super.loadView()
        let navi = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NAVI") as! Navi
        navigationBar.barTintColor = navi.navigationBar.barTintColor
    }
}
