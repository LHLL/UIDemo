//
//  GRTabBarController.swift
//  GRTabBarController
//
//  Created by Xu, Jay on 2/5/18.
//  Copyright © 2018 wf. All rights reserved.
//

import UIKit

typealias GRVC = Reversable & UIViewController

class GRTabBarController: CustomTransitionViewController {
    
    @IBOutlet weak var leftLeading: NSLayoutConstraint!
    @IBOutlet weak var leftTrailing: NSLayoutConstraint!
    @IBOutlet weak var rightTrailing: NSLayoutConstraint!
    @IBOutlet weak var rightLeading: NSLayoutConstraint!
    @IBOutlet weak var container: UIView!
    @IBOutlet weak var height: NSLayoutConstraint!
    
    //Buttons
    @IBOutlet weak var camerBtn: UIButton!
    @IBOutlet var btns: [UIButton]!
    private var icons:[UIImage] = [
        GroupreelImage.shared.homeImage!,
        GroupreelImage.shared.eventImage!,
        GroupreelImage.shared.MessageImage!,
        GroupreelImage.shared.SettingImage!
    ]
    private var sub:[UIView] = []
    private var viewControllers:[UINavigationController] = [
        GRNavigationController(rootViewController:UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CEVC")),
        GRNavigationController(rootViewController:UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UPVC")),
        GRNavigationController(rootViewController:UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NVC")),
        GRNavigationController(rootViewController:UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "STVC"))
    ]
    private var selectedIndex:Int = 0
    private var monitor:NSKeyValueObservation!
    var selectedColor:UIColor{
        get{
            return GroupreelColor.selectedColor
        }
        set{
            GroupreelColor.selectedColor = newValue
        }
    }
    
    var selectedViewController:UIViewController{
        return viewControllers[selectedIndex].topViewController!
    }
    
    var events:[Event] = []
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    //MARK:Initilization
    static func loadFromNib()->GRTabBarController{
        return GRTabBarController(nibName: "GRTabBarController", bundle: nil)
    }
    
    @available(*,unavailable)
    init() {
        super.init(nibName: nil, bundle: nil)
    }
    
    private override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        monitor = Invigilator.shared.observe(\.isBash, changeHandler: { (flag, change) in
            if flag.isBash {
                self.showCameraBtn()
            }else{
                self.hideCameraBtn()
            }
        })
        UploadManager.shared.delegate = self
    }
    
    @available(*,unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK:Life Cycle
    override func loadView() {
        super.loadView()
        for (index,btn) in btns.enumerated(){
            btn.setImage(icons[index], for: .normal)
        }
        viewControllers.forEach{
            let v = $0.view
            v?.frame = container.bounds
            container.addSubview(v!)
            if $0.topViewController is UpcomingViewController{
                ($0.topViewController as! UpcomingViewController).events = events
            }
            addChildViewController($0)
            sub.append(v!)
        }
        childViewControllers[selectedIndex].didMove(toParentViewController: self)
        container.bringSubview(toFront: sub[selectedIndex])
        didSelect(btns[selectedIndex])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showTitle()
        Invigilator.shared.errorHandler = { (title,content) in
            self.showAlert(with: title, and: content)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        rightLeading.constant = (rightLeading.constant + rightTrailing.constant)/2
        rightTrailing.constant = (rightLeading.constant + rightTrailing.constant)/2
        leftTrailing.constant = (leftLeading.constant + leftTrailing.constant)/2
        leftLeading.constant = (leftLeading.constant + leftTrailing.constant)/2
        Invigilator.shared.isBash = selectedViewController is BashViewController
    }
    
    deinit {
        monitor = nil
    }

    //MARK:IBActions
    @IBAction func showCamera(_ sender: UIButton) {
        if height.constant == 50{
            sender.rotate()
        }else{
            if let flag = Invigilator.shared.readyToShoot?(),flag {
                startShootingVideo()
            }
        }
    }
    
    @IBAction func didSelect(_ sender: UIButton) {
        for (index,btn) in btns.enumerated(){
            btn.setImage(icons[index], for: .normal)
            btn.isClicked = false
            btn.tintColor = .white
        }
        selectedIndex = btns.index(of: sender)!
        sender.didClickOn()
        showSelectedViewController()
    }
    
    private func showSelectedViewController(){
        childViewControllers[selectedIndex].didMove(toParentViewController: self)
        container.bringSubview(toFront: sub[selectedIndex])
    }
    
    private func hideCameraBtn(){
        height.constant = 50
        view.layoutSubviews()
        camerBtn.layer.cornerRadius = camerBtn.bounds.height/2
        camerBtn.setImage(GroupreelImage.shared.filmImage!, for: .normal)
    }
    
    private func showCameraBtn(){
        height.constant = 75
        view.layoutSubviews()
        camerBtn.layer.cornerRadius = camerBtn.bounds.height/2
        camerBtn.setImage(GroupreelImage.shared.cameraImage!, for: .normal)
    }
    
    private func startShootingVideo(){
        let des = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SHOOTING")
        present(des, animated: true, completion: nil)
    }
}

extension GRTabBarController:UploadManagerDelegate {
    
    func doneDoneDone(id: Int) {
        
    }
    
    func didEncounter(error: String) {
        DispatchQueue.main.async {
            self.showAlert(with: "Video Upload Faild", and: error)
        }
    }
}
