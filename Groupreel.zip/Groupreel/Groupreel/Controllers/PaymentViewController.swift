//
//  PaymentViewController.swift
//  Groupreel
//
//  Created by Lynn on 12/11/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class PaymentViewController: UIViewController {
    
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var taxLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var codeTextField: UITextField!
    @IBOutlet weak var paymentBtn: TransitionButton!
    @IBOutlet weak var settingBtn: UIButton!
    @IBOutlet weak var manageBtn: UIButton!
    @IBOutlet weak var eventBtn: UIButton!
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var backgroundView: UIView!
    
    private var gradientLayer: CAGradientLayer!
    
    var event:Event!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
        backView.layer.cornerRadius = 5
    }
    
    override func viewDidLayoutSubviews() {
        //gradient color
        paymentBtn.layer.cornerRadius = paymentBtn.frame.size.height / 2
        gradientView.layer.cornerRadius = gradientView.frame.size.height / 2
        gradientView.layer.masksToBounds = true
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = gradientView.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        gradientView.layer.addSublayer(gradientLayer)
    }

    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        totalLabel.textColor = GroupreelColor.blingGreen
        
        homeBtn.setImage(GroupreelImage.shared.homeImage, for: .normal)
        eventBtn.setImage(GroupreelImage.shared.eventImage, for: .normal)
        manageBtn.setImage(GroupreelImage.shared.MessageImage, for: .normal)
        settingBtn.setImage(GroupreelImage.shared.SettingImage, for: .normal)
    }
    
    @IBAction func makePayment(_ sender: TransitionButton) {
        sender.isEnabled = false
        sender.startAnimation()
        event.payment = [Payment(a: 100, d: 20000, token: "fdsfasdfds", p: Cache.currentUser)]
        let request = CreatEventRequest(event: event)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                sender.isEnabled = true
                sender.stopAnimation(animationStyle: .expand, completion: {
                    let story = UIStoryboard.init(name: "Main", bundle: nil)
                    let controller = story.instantiateViewController(withIdentifier: "BVC") as! BashViewController
                    controller.event = response?.event
                    DispatchQueue.main.async {
                        self.navigationController?.pushViewController(controller, animated: true)
                    }
                })
            }else if let e = response?.error{
                DispatchQueue.main.async(execute: { () -> Void in
                    sender.stopAnimation(animationStyle: .shake, completion: {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                            self.showAlert(with: "Cannot Create Event", and: e.description)
                            sender.isEnabled = true
                        })
                    })
                })
            }else if let e = error {
                DispatchQueue.main.async(execute: { () -> Void in
                    sender.stopAnimation(animationStyle: .shake, completion: {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                            self.showAlert(with: "Cannot Create Event", and: e.description)
                            sender.isEnabled = true
                        })
                    })
                })
            }
        }
    }
}

extension PaymentViewController:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        codeTextField.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if textField.text == ""{
            textField.text = "Enter Promo Code"
        }
        return true
    }
}

