//
//  Navi.swift
//  Groupreel
//
//  Created by Xu, Jay on 1/16/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class Navi: UINavigationController {

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
