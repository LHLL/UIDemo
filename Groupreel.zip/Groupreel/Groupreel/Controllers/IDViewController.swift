//
//  IDViewController.swift
//  Groupreel
//
//  Created by Lynn on 2/5/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class IDViewController: UIViewController {
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var joinBtn: UIButton!
    @IBOutlet weak var codeTF: UITextField!
    
    private var gradientLayer: CAGradientLayer!
    private var flag = true
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard flag else{return}
        flag = false
        UISetup()
    }
    
    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        joinBtn.layer.cornerRadius = joinBtn.frame.size.height / 2
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = joinBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.cornerRadius = joinBtn.frame.size.height / 2
        joinBtn.layer.insertSublayer(gradientLayer, at: 0)
        joinBtn.layer.masksToBounds = true
        showTitle()
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.shared.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
    }

    @IBAction func joinEvent(_ sender: TransitionButton) {
        sender.stopAnimation()
        sender.isEnabled = false
        let request = EventRequest(id: codeTF.text!)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                let story = UIStoryboard.init(name: "Main", bundle: nil)
                let controller = story.instantiateViewController(withIdentifier: "BVC")
                (controller as! BashViewController).event = response?.event
                DispatchQueue.main.async {
                    sender.isEnabled = true
                    sender.stopAnimation(animationStyle: .expand, revertAfterDelay: 0, completion: {
                        self.navigationController?.pushViewController(controller, animated: true)
                    })
                }
            }else if let e = response?.error{
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: {
                    self.showAlert(with: "Invalid Event", and: e.description)
                    sender.isEnabled = true
                })
            }else if let e = error {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: {
                    self.showAlert(with: "Invalid Event", and: e.description)
                    sender.isEnabled = true
                })
            }
        }
    }
}

extension IDViewController:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        codeTF.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
