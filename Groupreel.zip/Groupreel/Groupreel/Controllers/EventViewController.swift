//
//  EventViewController.swift
//  Groupreel
//
//  Created by Lynn on 12/7/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class EventViewController: CustomTransitionViewController {
    
    @IBOutlet weak var settingBtn: UIButton!
    @IBOutlet weak var manageBtn: UIButton!
    @IBOutlet weak var eventBtn: UIButton!
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var tabBarView: UIView!
    @IBOutlet weak var eventTableView: UITableView!
    @IBOutlet weak var backgroundView: UIView!
    
    var price:String?
    var event = Event()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
        registerCell()
        event.drafter = Cache.currentUser
    }
    
    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        
        homeBtn.setImage(GroupreelImage.homeImage, for: .normal)
        eventBtn.setImage(GroupreelImage.eventImage, for: .normal)
        manageBtn.setImage(GroupreelImage.MessageImage, for: .normal)
        settingBtn.setImage(GroupreelImage.SettingImage, for: .normal)
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
        showTitle()
    }
    
    private func registerCell() {
        eventTableView.register( UINib(nibName: "EventNameCell", bundle: nil), forCellReuseIdentifier: "EventNameCell")
        eventTableView.register( UINib(nibName: "ScheduleCell", bundle: nil), forCellReuseIdentifier: "ScheduleCell")
        eventTableView.register( UINib(nibName: "AmountCell", bundle: nil), forCellReuseIdentifier: "AmountCell")
        eventTableView.register( UINib(nibName: "MusicCell", bundle: nil), forCellReuseIdentifier: "MusicCell")
        eventTableView.register( UINib(nibName: "NoteCell", bundle: nil), forCellReuseIdentifier: "NoteCell")
        eventTableView.register( UINib(nibName: "CheckoutCell", bundle: nil), forCellReuseIdentifier: "CheckoutCell")
    }
    
    @objc
    private func goBack(){
        navigationController?.popViewController(animated: true)
    }
}

extension EventViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell?
        if indexPath.section == 0{
            cell = tableView.dequeueReusableCell(withIdentifier: "EventNameCell", for: indexPath)
            (cell as! EventNameCell).eventName.text = event.name
            (cell as! EventNameCell).eventName.text = event.id
            (cell as! EventNameCell).delegate = self
        }else if indexPath.section == 1{
            cell = tableView.dequeueReusableCell(withIdentifier: "ScheduleCell", for: indexPath)
            (cell as! ScheduleCell).timeView.isHidden = event.start == nil
            (cell as! ScheduleCell).trigger.isHidden = event.start != nil
            (cell as! ScheduleCell).delegate = self
            (cell as! ScheduleCell).startDate.text = event.startTime ?? ""
            (cell as! ScheduleCell).endDate.text = event.endTime ?? ""
        }else if indexPath.section == 2{
            cell = tableView.dequeueReusableCell(withIdentifier: "AmountCell", for: indexPath)
            (cell as! AmountCell).delegate = self
        }else if indexPath.section == 3{
            cell = tableView.dequeueReusableCell(withIdentifier: "MusicCell", for: indexPath)
            (cell as! MusicCell).delegate = self
            (cell as! MusicCell).musicTextField.text = event.musicNote
        }else if indexPath.section == 4{
            cell = tableView.dequeueReusableCell(withIdentifier: "NoteCell", for: indexPath)
            (cell as! NoteCell).delegate = self
        }else{
            cell = tableView.dequeueReusableCell(withIdentifier: "CheckoutCell", for: indexPath)
            (cell as! CheckoutCell).delegate = self
        }
        return cell!
    }
}

extension EventViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0{
            return 111
        }else if indexPath.section == 1{
            return 125
        }else if indexPath.section == 2{
            return 228
        }else if indexPath.section == 3{
            return 109
        }else if indexPath.section == 4{
            return 109
        }else{
            return 64
        }
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 1 {
            return 30
        }else{
            return 20
        }
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = UIColor.clear
        return v
    }
}

extension EventViewController:CheckoutCellDelegate{
    func toPayment() {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toPay = story.instantiateViewController(withIdentifier: "PVC") as! PaymentViewController
        toPay.event = event
        DispatchQueue.main.async {
            self.navigationController?.pushViewController(toPay, animated: true)
        }
    }
}

extension EventViewController:ScheduleCellDelegate{
    func chooseDate() {
        view.endEditing(true)
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toDate = story.instantiateViewController(withIdentifier: "CaVC")
        navigationController?.pushViewController(toDate, animated: true)
    }
}

extension EventViewController:EventNameCellDelegate {
    func shouldUpdate(name:String){
        event.name = name
    }
}

extension EventViewController:NoteCellDelegate{
    func update(note: String) {
        event.editorNote = note
    }
}

extension EventViewController:MusicCellDelegate{
    func update(music: String) {
        event.musicNote = music
    }
}

extension EventViewController:AmountCellDelegate{
    func shouldUpdate(duration: Int) {
        event.duration = duration
    }
}

