//
//  EventViewController.swift
//  Groupreel
//
//  Created by Lynn on 12/7/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class EventViewController: CustomTransitionViewController {
    
    @IBOutlet weak var eventTableView: UITableView!
    @IBOutlet weak var backgroundView: UIView!
    
    var price:String?
    var event = Event()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
        registerCell()
        event.drafter = Cache.currentUser
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.shared.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
    }
    
    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        showTitle()
    }
    
    private func registerCell() {
        eventTableView.register( UINib(nibName: "CreateEventCell", bundle: nil), forCellReuseIdentifier: "CreateEventCell")
    }
}

extension EventViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CreateEventCell", for: indexPath)
        (cell as! CreateEventCell).eventNameTF.text = event.name
        (cell as! CreateEventCell).eventNameTF.text = event.id
        (cell as! CreateEventCell).timeView.isHidden = event.start == nil
        (cell as! CreateEventCell).trigger.isHidden = event.start != nil
        (cell as! CreateEventCell).startDate.text = event.startTime ?? ""
        (cell as! CreateEventCell).endDate.text = event.endTime ?? ""
        (cell as! CreateEventCell).musicTextField.text = event.musicNote
        (cell as! CreateEventCell).delegate = self
        return cell
    }
}

extension EventViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}

extension EventViewController:CreateEventCellDelegate{
    func toPayment() {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toPay = story.instantiateViewController(withIdentifier: "PVC") as! PaymentViewController
        toPay.event = event
        DispatchQueue.main.async {
            self.navigationController?.pushViewController(toPay, animated: true)
        }
    }
    
    func chooseDate() {
        view.endEditing(true)
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toDate = story.instantiateViewController(withIdentifier: "CaVC")
        navigationController?.pushViewController(toDate, animated: true)
    }
    
    func shouldUpdate(name:String){
        event.name = name
    }
    
    func updateNote(note: String) {
        event.editorNote = note
    }
    
    func update(music: String) {
        event.musicNote = music
    }
    
    func shouldUpdate(duration: Int) {
        event.duration = duration
    }
}

