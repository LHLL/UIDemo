//
//  SettingViewController.swift
//  Groupreel
//
//  Created by Xu, Jay on 2/7/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class SettingViewController: UIViewController {

    @IBOutlet weak var temp: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showTitle()
        temp.loadGif(name: "uc")
    }

}
