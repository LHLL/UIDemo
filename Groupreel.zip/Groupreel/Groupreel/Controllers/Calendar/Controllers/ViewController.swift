//
//  ViewController.swift
//  CalendarDemo
//
//  Created by Xu, Jay on 1/23/18.
//  Copyright © 2018 wf. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var topContainer: UIView!
    @IBOutlet weak var botContainer: UIView!
    @IBOutlet weak var startBtn: UIButton!
    @IBOutlet weak var endBtn: UIButton!
    @IBOutlet weak var startTF: UITextField!
    @IBOutlet weak var endTF: UITextField!
    
    private var startPicker = UIDatePicker()
    private var endPicker = UIDatePicker()
    private var gradientLayer: CAGradientLayer!
    private var calendar:UIView!
    private var calendarController:CalendarViewController!
    private var origin:CGRect!
    private var btnOrigin:CGRect!
    private var reset = false
    private var events = Event()
    private var st:Date? = nil
    private var et:Date? = nil
    private var start:Date? = nil {
        didSet{
            if start == nil {
                self.startBtn.setTitle("Select Date", for: .normal)
            }else{
                let formatter = DateFormatter()
                formatter.dateFormat = "EEE, MMM dd"
                self.startBtn.setTitle(formatter.string(from: start!), for: .normal)
            }
        }
    }
    private var end:Date? = nil{
        didSet{
            if end == nil {
                self.endBtn.setTitle("Select Date", for: .normal)
            }else{
                let formatter = DateFormatter()
                formatter.dateFormat = "EEE, MMM dd"
                self.endBtn.setTitle(formatter.string(from: end!), for: .normal)
            }
        }
    }
    
    override func viewDidLoad() {
        events.start = startBtn.titleLabel?.text
        events.ends = endBtn.titleLabel?.text
        events.startTime = startTF.text
        events.endTime = endTF.text
        
        topContainer.layer.cornerRadius = 3
        botContainer.layer.cornerRadius = 3
        super.viewDidLoad()
        configureTFs()
        showTitle()
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.shared.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        configureCalendar()
        origin = botContainer.frame
        btnOrigin = saveBtn.frame
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        //gradient color
        saveBtn.layer.cornerRadius = saveBtn.frame.size.height / 2
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = saveBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        saveBtn.layer.insertSublayer(gradientLayer, at: 0)
        saveBtn.layer.masksToBounds = true
        
        if reset {
            self.botContainer.frame = CGRect(origin: CGPoint(x:self.topContainer.frame.origin.x,
                                                             y:self.topContainer.frame.origin.y + 100 + self.calendar.bounds.height),
                                             size: self.botContainer.bounds.size)
            self.saveBtn.frame = CGRect(origin: CGPoint(x:self.topContainer.frame.origin.x,
                                                        y:self.topContainer.frame.origin.y + 170 + self.calendar.bounds.height),
                                        size: self.saveBtn.bounds.size)
        }
    }
    
    private func configureTFs(){
        startPicker.datePickerMode = .time
        startPicker.minuteInterval = 5
        startPicker.addTarget(self, action: #selector(handleDateChange), for: .valueChanged)
        startTF.inputView = startPicker
        startTF.inputAccessoryView = keyboardToolBar
        
        endPicker.datePickerMode = .time
        endPicker.minuteInterval = 5
        endPicker.addTarget(self, action: #selector(handleDateChange), for: .valueChanged)
        endTF.inputView = endPicker
        endTF.inputAccessoryView = keyboardToolBar
    }
    
    @objc
    private func handleDateChange(sender:UIDatePicker){
        if st == nil {
            st = sender.date
        }else{
            et = sender.date
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        if sender == startPicker {
            startTF.text = formatter.string(from: sender.date)
        }else{
            endTF.text = formatter.string(from: sender.date)
            hideCalendarView()
        }
    }
    
    @IBAction func saveTime(_ sender: UIButton) {
        let dateFormatter = DateFormatter()
        for vc in navigationController!.viewControllers {
            if vc is EventViewController {
                (vc as! EventViewController).event.startTime = startBtn.currentTitle! + "\n" + startTF.text!
                (vc as! EventViewController).event.endTime = endBtn.currentTitle! + "\n" + endTF.text!
                dateFormatter.dateFormat = "EEE, MMM dd,yyyy h:mma"
                let sd = dateFormatter.date(from: startBtn.currentTitle! + ",\(Calendar.current.component(.year, from: start!))" + " " + startTF.text!)!
                let ed = dateFormatter.date(from: endBtn.currentTitle! + ",\(Calendar.current.component(.year, from: end!))" + " " + endTF.text!)!
                dateFormatter.dateFormat = "MMM d,yyyy h:mm a"
                (vc as! EventViewController).event.start = dateFormatter.string(from: sd)
                (vc as! EventViewController).event.ends = dateFormatter.string(from: ed)
                (vc as! EventViewController).eventTableView.reloadData()
                break
            }
        }
        navigationController?.popViewController(animated: true)
    }
    
    private func configureCalendar(){
        calendarController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CVVC") as! CalendarViewController
        calendar = calendarController.view
        calendar.frame = CGRect(x: 0,
                                y: 0,
                                width: UIScreen.main.bounds.width,
                                height: 298)
        calendar.isHidden = true
        calendarController.startHandler = { [unowned self] date in
            self.reset = true
            self.start = date
        }
        calendarController.endHandler = { [unowned self] date in
            self.reset = false
            self.end = date
        }
        self.view.addSubview(calendar)
        addChildViewController(calendarController)
        calendarController.didMove(toParentViewController: self)
    }
    
    @IBAction func pickAStart(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5, animations: {
            self.calendar.frame = CGRect(origin: CGPoint(x:0,
                                                         y:self.topContainer.frame.origin.y + 55),
                                         size: self.calendar.bounds.size)
            self.botContainer.frame = CGRect(origin: CGPoint(x:self.topContainer.frame.origin.x,
                                                             y:self.topContainer.frame.origin.y + 100 + self.calendar.bounds.height),
                                             size: self.botContainer.bounds.size)
            self.saveBtn.frame = CGRect(origin: CGPoint(x:self.topContainer.frame.origin.x,
                                                        y:self.topContainer.frame.origin.y + 170 + self.calendar.bounds.height),
                                        size: self.saveBtn.bounds.size)
        }, completion: { (done) in
            self.calendar.isHidden = false
            self.calendarController.singleSelection = true
            self.calendarController.isStart = true
        })
    }
    
    @IBAction func pickEnd(_ sender: UIButton) {
        guard startBtn.currentTitle != "Select Date"else{
            startBtn.shake()
            viberate()
            return
        }
        guard startTF.text != "" else{
            startTF.shake()
            viberate()
            return
        }
        UIView.animate(withDuration: 0.5, animations: {
            self.calendar.frame = CGRect(origin: CGPoint(x:0,
                                                         y:self.origin.origin.y + 55),
                                         size: self.calendar.bounds.size)
            self.saveBtn.frame = CGRect(origin: CGPoint(x:self.topContainer.frame.origin.x,
                                                        y:self.topContainer.frame.origin.y + 170 + self.calendar.bounds.height),
                                        size: self.saveBtn.bounds.size)
            self.botContainer.frame = self.origin
        }, completion: { (done) in
            self.calendar.isHidden = false
            self.calendarController.singleSelection = false
            self.calendarController.isStart = false
        })
    }
    
    private func hideCalendarView(){
        self.calendar.isHidden = true
        UIView.animate(withDuration: 0.5) {
            self.botContainer.frame = self.origin
            self.saveBtn.frame = self.btnOrigin
        }
    }
}

extension ViewController:UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == startTF {
            if startBtn.currentTitle == "Select Date"{
                startTF.shake()
                viberate()
                return false
            }else{
                return true
            }
        }else {
            if endBtn.currentTitle == "Select Date"{
                startTF.shake()
                viberate()
                return false
            }else{
                return true
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let calendar = Calendar.current
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        if textField == startTF {
            let nextDiff = 15 - calendar.component(.minute, from: Date()) % 15
            let d = calendar.date(byAdding: .minute, value: nextDiff, to: Date()) ?? Date()
            startPicker.setDate(d, animated: true)
            startTF.text = formatter.string(from:startPicker.date)
        }else{
            let st = formatter.date(from: startTF.text!)!
            let nextDiff = 15 - calendar.component(.minute, from: st) % 15
            let d = calendar.date(byAdding: .minute, value: nextDiff, to: st) ?? Date()
            endPicker.setDate(d, animated: true)
            endTF.text = formatter.string(from: endPicker.date)
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == endTF {
            hideCalendarView()
        }
//        guard let start = st,start.isInTheFuture else{
//            st = nil
//            textField.text = nil
//            textField.shake()
//            startTF.becomeFirstResponder()
//            return
//        }
//        guard et != nil && et! > st! else{
//            et = nil
//            textField.text = nil
//            endTF.shake()
//            endTF.becomeFirstResponder()
//            return
//        }
    }
}
