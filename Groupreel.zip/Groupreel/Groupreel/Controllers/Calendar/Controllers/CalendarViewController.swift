//
//  HomeViewController.swift
//  Widok
//
//  Created by Xu, Jay on 1/17/18.
//  Copyright © 2018 Infamous Worldwide. All rights reserved.

import UIKit

class CalendarViewController: UIViewController {

    //MARK: - Variables: *Calendar, WeekDays menu bar
    
    @IBOutlet var calendarView: CVCalendarView!
    @IBOutlet var menuView: CVCalendarMenuView!
    
    //MARK: - Variables: *topLabel:year,dateLabel: Weekday,Month,Date
    @IBOutlet var currentYearAndMonthLabel: UILabel!
    @IBOutlet weak var nextLabel: UILabel!
    @IBOutlet weak var previousLabel: UILabel!
    
    var startHandler:((Date?)->Void)?
    var endHandler:((Date?)->Void)?
    
    private let formatter = DateFormatter()
    
    private let date = Date().addNDays(n: -1)
    
    private var isLaunched  = false
    private var isMovingOnFromCurrentDate = false
    
    private var currentCalendar: Calendar?
    
    private var start:Date? = nil {
        didSet{
            startHandler?(start)
        }
    }
    private var end:Date? = nil {
        didSet{
            endHandler?(end)
        }
    }
    
    override func awakeFromNib() {
        // initilize the calendar
        currentCalendar = Calendar.init(identifier: .gregorian)
        
        // get the current timezone and set to calendar
        if let timeZone = TimeZone.init(identifier: TimeZone.current.identifier) {
            currentCalendar?.timeZone = timeZone
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        /// Commit calendar and menu view
        menuView.commitMenuViewUpdate()
        calendarView.commitCalendarViewUpdate()
    }
    
    /// MARK: configure ui elements
    private func configureUI(){
        calendarView.changeDaysOutShowingState(shouldShow: false)
        //calendarView.toggleViewWithDate(Date())
        presentedDateUpdated(CVDate(date: date))

        // add underline for menu view
        view.layoutIfNeeded()
        
        ///Add the botton line for menu weekdays view
        //menuView.layer.addBorder(edge: .bottom, color: WellsFargoColor.kGreenHouseCoolGray, thickness: 0.5)
        calendarView.calendarAppearanceDelegate = self
        calendarView.calendarDelegate = self
        
        formatter.dateFormat = "dd"
    }
    
    
    private func dismissButtonTapped(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
}

///MARK : CVCalendar delegate methods
extension CalendarViewController: CVCalendarViewDelegate, CVCalendarMenuViewDelegate {
    func dayOfWeekFont() -> UIFont {
        return UIFont.systemFont(ofSize: 15.0)
    }
    
    
    ///MARK: See calendar by month ( there are other options like by Week...
    func presentationMode() -> CalendarMode {
        return .monthView
    }
    
    ///MARK:First colunm of the calendar is Sundays
    func firstWeekday() -> Weekday {
        return .sunday
    }
    

    ///MARK: return false for the ability to select a range
    /// **if return true, it will be able  function like hotel apps' select range**
    func shouldSelectRange() -> Bool {
        return false
    }
    
    func calendar() -> Calendar? {
        return currentCalendar
    }
    
    func earliestSelectableDate() -> Date {
        return start ?? Date().addNDays(n: -1)
    }
    
    
    func shouldAutoSelectDayOnMonthChange() -> Bool {
        return isLaunched
    }
    
    func shouldShowWeekdaysOut() -> Bool {
        return false
    }
    
    
    func shouldScrollOnOutDayViewSelection() -> Bool {
        return true
    }
    
    func disableScrollingBeforeDate() -> Date {
        return Date()
    }
    
    
    func dayOfWeekTextColor() -> UIColor {
        return .white
    }
    
    
    /// - MARK : main delegate method
    /// - Warning: **cautious when changing the logics in this method**
    /// - MARK:         - date is today
    ///                 - date is in this month but not today 
    ///                 - date beyond this month
    func didSelectDayView(_ dayView: CVCalendarDayView, animationDidFinish: Bool) {
        if start == nil {
            start = dayView.date.date
        }else if end == nil {
            end = dayView.date.date
        }
    }

    ///MARK: Here is the update for all the date labels.
    func presentedDateUpdated(_ date: CVDate) {
        currentYearAndMonthLabel.text =  date.globalDescription
        
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM"
        
        let pre = Calendar.current.date(byAdding: .month, value: -1, to: date.date)
        let preMonth = formatter.string(from: pre!)
        previousLabel.text = preMonth
        
        let post = Calendar.current.date(byAdding: .month, value: 1, to: date.date)
        let postMonth = formatter.string(from: post!)
        nextLabel.text = postMonth
    }
    ///Mark: weekday menu bar with short weekday symbols *eg: Monday -> M, Tuesday -> T*
    func weekdaySymbolType() -> WeekdaySymbolType {
        return .veryShort
    }
}

// MARK : appearance delegate methods
extension CalendarViewController: CVCalendarViewAppearanceDelegate {
    
    func dayLabelWeekdayDisabledColor() -> UIColor {
        return UIColor.lightGray
    }
    
    func dayLabelPresentWeekdayInitallyBold() -> Bool {
        return true
    }

    func dayLabelFont(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIFont {
        return UIFont.systemFont(ofSize: 18)
    }
    
    func dayLabelColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        calendarView.contentController.reloadInputViews()
        switch (weekDay, status, present) {
        case (_, .selected, _): return .white
        case (_, .disabled, .present): return .white
        case (_ , .in, _): return .white
        case (_, .out, .not): return .lightGray
        default: return .lightGray
        }
    }
    
    func dayLabelBackgroundColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        //case (_, .out, _): return UIColor.clear
        case (_, .out, .present): return .white
        case (_, .selected, _), (_, .highlighted, _): return UIColor(displayP3Red: 111/225.0,
                                                                     green: 193/225.0,
                                                                     blue: 116/225.0,
                                                                     alpha: 1)
        default: return nil
        }
    }
}

//extension CalendarViewController {
//
//    ///MARK: grey out the past days
//    func disablePreviousDays() {
//        for weekV in calendarView.contentController.presentedMonthView.weekViews {
//            for dayView in weekV.dayViews {
//                if isBeforeThanDate(dayView, date: date) {
//                    dayView.isUserInteractionEnabled = false
//                    dayView.dayLabel.textColor = calendarView.appearance.dayLabelWeekdayOutTextColor
//                }
//            }
//        }
//    }
//    ///MARK: compare dates to the date after today.
//    func isBeforeThanDate(_ dayView: CVCalendarDayView, date: Date) -> Bool {
//        return currentCalendar!.compare(dayView.date.convertedDate()!, to: date, toGranularity: .nanosecond) == .orderedAscending
//    }
//}

