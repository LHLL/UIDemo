//
//  HomeViewController.swift
//  Widok
//
//  Created by Xu, Jay on 1/17/18.
//  Copyright © 2018 Infamous Worldwide. All rights reserved.

import Foundation

struct DateComps {
    var selectedDate: Date
    var isSelected: Bool
    
    init(aDate: Date, selected:Bool){
        selectedDate = aDate
        isSelected = selected
    }
    
    var selectedDay: Int {
        return Calendar.current.component(.day, from: selectedDate)
    }
    
    var selectedMonth: Int {
        return Calendar.current.component(.month, from: selectedDate)
    }
    
    var selectedYear: Int {
        return Calendar.current.component(.year, from: selectedDate)
        
    }
    
    var startOfMonthDay: Date {
        return selectedDate.startOfMonth()
    }
    
    var endOfMonthDay: Date {
        return selectedDate.endOfMonth()
        
    }
    
}
