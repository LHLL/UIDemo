//
//  SignViewController.swift
//  Groupreel
//
//  Created by Lynn on 11/29/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit
import LocalAuthentication

class SignViewController: UIViewController {
    
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var signInBtn: UIButton!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isHidden = true
        navigationItem.leftBarButtonItem?.image = IonIcons.image(withIcon: ion_chevron_left,
                                                                 iconColor: UIColor.white,
                                                                 iconSize: 30,
                                                                 imageSize: CGSize(width: 30, height: 30))
        
    }
    
    override func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func signIn(_ sender: UIButton) {
        guard !Cache.bioAuth else{
            bioAuth()
            return
        }
        toLoginPage()
    }
    
    @IBAction func signUp(_ sender: UIButton) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toSignup = story.instantiateViewController(withIdentifier: "SUVC")
        navigationController?.pushViewController(toSignup, animated: true)
    }
    
    private func toLoginPage(){
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toSignin = story.instantiateViewController(withIdentifier: "SIVC")
        navigationController?.pushViewController(toSignin, animated: true)
    }
    
    private func toMain(_ events:[Event]){
        let tab = GRTabBarController.loadFromNib()
        tab.events = events
        self.present(tab, animated: true, completion: nil)
    }
    
    private func bioAuth(){
        let context = LAContext()
        var error:NSError?
        if context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) {
            context.evaluatePolicy(.deviceOwnerAuthentication,localizedReason: "App wants to use touch ID/Face ID to authenticate user",reply: { (success, error) in
                if success {
                    Cache.authenticateUser({ (flag, events, error) in
                        DispatchQueue.main.async {
                            if let e = events {
                                self.toMain(e)
                            }else if let e = error{
                                self.showAlert(with: "Autentication Failed", and: e)
                                self.toLoginPage()
                            }
                        }
                    })
                }else{
                    DispatchQueue.main.async {
                        self.showAlert(with: "Autentication Failed", and: error!.localizedDescription)
                        self.toLoginPage()
                    }
                }
            })
        }
    }
}
