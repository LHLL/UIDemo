//
//  SignViewController.swift
//  Groupreel
//
//  Created by Lynn on 11/29/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class SignViewController: UIViewController {
    
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var signInBtn: UIButton!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isHidden = true
        navigationItem.leftBarButtonItem?.image = IonIcons.image(withIcon: ion_chevron_left,
                                                                 iconColor: UIColor.white,
                                                                 iconSize: 30,
                                                                 imageSize: CGSize(width: 30, height: 30))
        
    }
    
    @objc
    private func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func signIn(_ sender: UIButton) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toSignin = story.instantiateViewController(withIdentifier: "SIVC")
        navigationController?.pushViewController(toSignin, animated: true)
    }
    
    @IBAction func signUp(_ sender: UIButton) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toSignup = story.instantiateViewController(withIdentifier: "SUVC")
        navigationController?.pushViewController(toSignup, animated: true)
    }

}
