//
//  BashViewController.swift
//  Groupreel
//
//  Created by Lynn on 11/3/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class BashViewController: UIViewController {
    
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var bashTableView: UITableView!
    
    var event:Event!{
        didSet{
            let ratio = Float(event.remaining/event.duration)
            durationUpdateHandler?(ratio)
        }
    }
    var durationUpdateHandler:((Float)->Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCell()
        UISetup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Invigilator.shared.isBash = true
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        Invigilator.shared.isBash = false
    }
    
    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        showTitle()
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.shared.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
    }
    
    private func registerCell() {
        bashTableView.register(UINib(nibName: "CodeCell", bundle: nil), forCellReuseIdentifier: "CodeCell")
        bashTableView.register(UINib(nibName: "AttendeesCell", bundle: nil), forCellReuseIdentifier: "AttendeesCell")
        bashTableView.register(UINib(nibName: "TimeCell", bundle: nil), forCellReuseIdentifier: "TimeCell")
        bashTableView.register(UINib(nibName: "FootageCell", bundle: nil), forCellReuseIdentifier: "FootageCell")
    }
}

extension BashViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CodeCell", for: indexPath)
            (cell as! CodeCell).codeText.text = event.id
            (cell as! CodeCell).codeText.textColor = GroupreelColor.blingGreen
            return cell
        }else if indexPath.section == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "AttendeesCell", for: indexPath)
            cell.backgroundColor = UIColor.clear
            (cell as! AttendeesCell).hostName.text = event.name
            (cell as! AttendeesCell).attendeeNumber.text = "\(event.guests.count) Members"
            (cell as! AttendeesCell).delegate = self
            return cell
        }else if indexPath.section == 2{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TimeCell", for: indexPath)
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMM dd,yyyy h:mm a"
            let start = dateFormatter.date(from: event.start)
            let end = dateFormatter.date(from: event.ends)
            dateFormatter.dateFormat = "MMM dd, yyyy ?h:mm a"
            var eventStart = dateFormatter.string(from: start!)
            eventStart = eventStart.replacingOccurrences(of: "?", with: "\n")
            var eventEnd = dateFormatter.string(from: end!)
            eventEnd = eventEnd.replacingOccurrences(of: "?", with: "\n")
            (cell as! TimeCell).startTime.text = eventStart
            (cell as! TimeCell).endTime.text = eventEnd
            (cell as! TimeCell).event = event
            return cell
        }else if indexPath.section == 3{
            let cell = tableView.dequeueReusableCell(withIdentifier: "FootageCell", for: indexPath)
            (cell as! FootageCell).startHour.text = String(event.duration / 3600) + "  Hour"
            (cell as! FootageCell).startMin.text = String((event.duration % 3600) / 60) + "  Min"
            (cell as! FootageCell).endHour.text =
                String(event.duration / 3600) + "  Hour"
            (cell as! FootageCell).endMin.text = String((event.duration % 3600) / 60) + "  Min"
            (cell as! FootageCell).delegate = self
            (cell as! FootageCell).durationLeft.progress = Float(event.remaining/event.duration)
            cell.backgroundColor = UIColor.clear
            durationUpdateHandler = { ratio in
                DispatchQueue.main.async {
                    (cell as! FootageCell).durationLeft.setProgress(ratio, animated: true)
                }
            }
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "RecordCell", for: indexPath)
            (cell as! RecordCell).firstImage.image = UIImage.init(named: "Record1")
            (cell as! RecordCell).secondImage.image = UIImage.init(named: "Record2")
            (cell as! RecordCell).thirdImage.image = UIImage.init(named: "Record3")
            (cell as! RecordCell).delegate = self
            return cell
        }
    }
}

extension BashViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = UIColor.clear
        return v
    }
}

extension BashViewController:RecordCellDelegate{
    func todisplayVideos() {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let toVideo = story.instantiateViewController(withIdentifier: "VVC")
        self.navigationController?.pushViewController(toVideo, animated: true)
    }
}

extension BashViewController:AttendeesCellDelegate{
    func toInviteController() {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let toInvite = storyBoard.instantiateViewController(withIdentifier: "IVC")
        self.navigationController?.pushViewController(toInvite, animated: true)
    }
}

extension BashViewController:FootageCellDelegate{
    func buyMoreFootage() {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let des = story.instantiateViewController(withIdentifier: "FTVC") as! FootageViewController
        self.navigationController?.pushViewController(des, animated: true)
    }
}
