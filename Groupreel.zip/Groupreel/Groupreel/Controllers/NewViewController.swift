//
//  NewViewController.swift
//  Groupreel
//
//  Created by Lynn on 1/10/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class NewViewController: UIViewController {
    
    @IBOutlet weak var newLabel: UILabel!
    @IBOutlet weak var backgroundView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
    }

    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        navigationItem.leftBarButtonItem?.image = IonIcons.image(withIcon: ion_chevron_left,
                                                                 iconColor: UIColor.white,
                                                                 iconSize: 30,
                                                                 imageSize: CGSize(width: 30, height: 30))
        
        newLabel.textColor = GroupreelColor.blingGreen
        showTitle()
    }
    
    override func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }

}
