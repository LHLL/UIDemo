//
//  NewViewController.swift
//  Groupreel
//
//  Created by Lynn on 1/10/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import UIKit

class NewViewController: UIViewController {
    @IBOutlet weak var newLabel: UILabel!
    @IBOutlet weak var cameraBtn: UIButton!
    @IBOutlet weak var settingBtn: UIButton!
    @IBOutlet weak var manageBtn: UIButton!
    @IBOutlet weak var eventBtn: UIButton!
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var backgroundView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
        // Do any additional setup after loading the view.
    }

    private func UISetup() {
        backgroundView.backgroundColor = GroupreelColor.backColor
        navigationItem.leftBarButtonItem?.image = IonIcons.image(withIcon: ion_chevron_left,
                                                                 iconColor: UIColor.white,
                                                                 iconSize: 30,
                                                                 imageSize: CGSize(width: 30, height: 30))
        
        
        //tabBarViewImage setup
        cameraBtn.layer.borderWidth = 4
        cameraBtn.layer.borderColor = UIColor.white.cgColor
        cameraBtn.layer.cornerRadius = cameraBtn.frame.size.height / 2
        
        homeBtn.setImage(GroupreelImage.shared.homeImage, for: .normal)
        eventBtn.setImage(GroupreelImage.shared.eventImage, for: .normal)
        manageBtn.setImage(GroupreelImage.shared.MessageImage, for: .normal)
        settingBtn.setImage(GroupreelImage.shared.SettingImage, for: .normal)
        cameraBtn.setImage(GroupreelImage.shared.cameraImage, for: .normal)
        
        newLabel.textColor = GroupreelColor.blingGreen
    }
    
    override func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }

}
