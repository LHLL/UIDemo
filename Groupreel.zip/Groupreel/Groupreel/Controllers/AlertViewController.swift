//
//  AlertViewController.swift
//  CameraTest
//
//  Created by Xu, Jay on 2/1/18.
//  Copyright © 2018 wf. All rights reserved.
//

import UIKit

class AlertViewController: UIViewController {

    @IBOutlet weak var alert: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var errorLabel: UILabel!
    
    var dismissHandler:(()->Void)?
    private var t = "Life's Hard"
    private var e = "Roboot Your Life"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let alertImg = IonIcons.image(withIcon: ion_alert_circled,
                                      size: 50,
                                      color: titleLabel.textColor)
        alert.image = alertImg
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        titleLabel.text = t
        errorLabel.text = e
    }
    
    func populateError(_ title:String,_ content:String){
        t = title
        e = content
    }
    
    @IBAction func dismissAlert(_ sender: UIButton) {
        dismissHandler?()
    }
}
