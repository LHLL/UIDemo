//
//  CreateEventViewController.swift
//  Groupreel
//
//  Created by Lynn on 12/6/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class CreateEventViewController: CustomTransitionViewController {
    
    @IBOutlet weak var joinBtn: UIButton!
    @IBOutlet weak var settingBtn: UIButton!
    @IBOutlet weak var manageBtn: UIButton!
    @IBOutlet weak var eventBtn: UIButton!
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var joinEventBtn: TransitionButton!
    @IBOutlet weak var creatEventBtn: TransitionButton!
    
    private var gradientLayer: CAGradientLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UISetup()
    }
    
    private func UISetup() {
        joinEventBtn.backgroundColor = GroupreelColor.blingGreen
        creatEventBtn.layer.cornerRadius = creatEventBtn.frame.size.height / 2
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = joinEventBtn.bounds
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.cornerRadius = creatEventBtn.frame.size.height / 2
        creatEventBtn.layer.insertSublayer(gradientLayer, at: 0)
        creatEventBtn.layer.masksToBounds = true
        //creatEventBtn.layer.masksToBounds = true
        joinEventBtn.layer.cornerRadius = joinEventBtn.frame.size.height / 2
        joinEventBtn.layer.masksToBounds = true
        joinBtn.layer.insertSublayer(gradientLayer, at: 0)
        joinBtn.layer.masksToBounds = true
        //tabBarViewImage setup
        homeBtn.setImage(GroupreelImage.homeImage, for: .normal)
        eventBtn.setImage(GroupreelImage.eventImage, for: .normal)
        manageBtn.setImage(GroupreelImage.MessageImage, for: .normal)
        settingBtn.setImage(GroupreelImage.SettingImage, for: .normal)
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: GroupreelImage.backImg,
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(goBack))
        
        showTitle()
        
//        var param = WCLShineParams()
//        param.bigShineColor = UIColor(rgb: (153,152,38))
//        param.smallShineColor = UIColor(rgb: (102,102,102))
//        homeBtn.params = param
//        homeBtn.image = WCLShineImage.custom(GroupreelImage.homeImage!)
    }
    
    @objc
    private func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }

    @IBAction func createEvent(_ sender: TransitionButton) {
        sender.startAnimation()
        sender.isEnabled = false
        let request = PriceRequest(duration: 1)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                let story = UIStoryboard.init(name: "Main", bundle: nil)
                let controller = story.instantiateViewController(withIdentifier: "EventVC") as! EventViewController
                controller.price = String(format: "%.2f", response!.unit)
                DispatchQueue.main.async {
                    sender.isEnabled = true
                    sender.stopAnimation(animationStyle: .expand, completion: {
                        self.navigationController?.pushViewController(controller, animated: false)
                    })
                }
            }else if let e = response?.error{
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                    self.showAlert(with: "Network Error", and: e.description)
                    sender.isEnabled = true
                })
            }else if let e = error {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                    self.showAlert(with: "Network Error", and: e.description)
                    sender.isEnabled = true
                })
            }
        }
    }
    
    @IBAction func joinAnEvent(_ sender: UIButton) {
        let story = UIStoryboard.init(name: "Main", bundle: nil)
        let toAnEvent = story.instantiateViewController(withIdentifier: "IDVC")
        DispatchQueue.main.async {
            self.navigationController?.pushViewController(toAnEvent, animated: true)
        }
    }
    
    @IBAction func joinEvent(_ sender: TransitionButton) {        sender.startAnimation()
        sender.isEnabled = false
        let request = AllEventRequest(with: Cache.currentUser)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                let story = UIStoryboard.init(name: "Main", bundle: nil)
                let controller = story.instantiateViewController(withIdentifier: "UPVC") as! UpcomingViewController
                controller.events = response?.events ?? []
                DispatchQueue.main.async {
                    sender.isEnabled = false
                    sender.stopAnimation(animationStyle: .expand, completion: {
                        self.navigationController?.pushViewController(controller, animated: false)
                    })
                }
            }else if let e = response?.error{
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                    self.showAlert(with: "Network Error", and: e.description)
                    sender.isEnabled = true
                })
            }else if let e = error {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                    self.showAlert(with: "Network Error", and: e.description)
                    sender.isEnabled = true
                })
            }
        }
    }
}
