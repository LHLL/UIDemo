//
//  CreateEventViewController.swift
//  Groupreel
//
//  Created by Lynn on 12/6/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit

class CreateEventViewController: CustomTransitionViewController{
    
    @IBOutlet weak var joinEventBtn: TransitionButton!
    @IBOutlet weak var creatEventBtn: TransitionButton!
    
    private var gradientLayer: CAGradientLayer!
    private var flag = true
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            self.UISetup()
        }
    }
    
    private func UISetup() {
        guard flag else{return}
        flag = false
        joinEventBtn.backgroundColor = GroupreelColor.blingGreen
        creatEventBtn.layer.cornerRadius = creatEventBtn.frame.size.height / 2
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = joinEventBtn.bounds
        gradientLayer.cornerRadius = creatEventBtn.frame.size.height / 2
        gradientLayer.colors = [GroupreelColor.gradientStartColor,
                                GroupreelColor.gradientEndColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        creatEventBtn.layer.insertSublayer(gradientLayer, at: 0)
        creatEventBtn.layer.masksToBounds = true
        joinEventBtn.layer.cornerRadius = joinEventBtn.frame.size.height / 2
        joinEventBtn.layer.masksToBounds = true
    }
    
    override func goBack(){
        navigationController?.popToRootViewController(animated: true)
    }

    @IBAction func createEvent(_ sender: TransitionButton) {
        sender.startAnimation()
        sender.isEnabled = false
        let request = PriceRequest(duration: 1)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                let story = UIStoryboard.init(name: "Main", bundle: nil)
                let controller = story.instantiateViewController(withIdentifier: "EventVC") as! EventViewController
                controller.price = String(format: "%.2f", response!.unit)
                DispatchQueue.main.async {
                    sender.isEnabled = true
                    sender.stopAnimation(animationStyle: .expand, completion: {
                        self.navigationController?.pushViewController(controller, animated: false)
                    })
                }
            }else if let e = response?.error{
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                    self.showAlert(with: "Network Error", and: e.description)
                    sender.isEnabled = true
                })
            }else if let e = error {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 , execute: {
                    self.showAlert(with: "Network Error", and: e.description)
                    sender.isEnabled = true
                })
            }
        }
    }
    
    @IBAction func joinAnEvent(_ sender: UIButton) {
        let story = UIStoryboard.init(name: "Main", bundle: nil)
        let toAnEvent = story.instantiateViewController(withIdentifier: "IDVC")
        DispatchQueue.main.async {
            self.navigationController?.pushViewController(toAnEvent, animated: true)
        }
    }

}
