//
//  Invigilator.swift
//  Groupreel
//
//  Created by Xu, Jay on 2/7/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import Foundation

class Invigilator: NSObject {
    
    static var shared = Invigilator()
    
    private override init() {}
    
    var readyToShoot:(()->Bool)?
    var errorHandler:((String,String)->Void)?
    
    @objc
    dynamic var isBash = false
}
