//
//  Extensions.swift
//  Groupreel
//
//  Created by Lynn on 8/24/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import UIKit
import CoreMotion
import AudioToolbox
import ImageIO

extension UIView{
    func shake() {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.05
        animation.repeatCount = 5
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x:self.center.x - 4.0, y:self.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x:self.center.x + 4.0, y:self.center.y))
        layer.add(animation, forKey: "position")
    }
    
    func rotate(){
        let rotateAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue = 0.0
        rotateAnimation.toValue = CGFloat(.pi * 2.0)
        rotateAnimation.duration = 0.2
        rotateAnimation.repeatCount = 3
        self.layer.add(rotateAnimation, forKey: nil)
    }
}

extension UIButton{
    
    struct InvisHelper {
        static var flag = false
    }
    
    var isClicked:Bool{
        get{
            return InvisHelper.flag
        }
        set{
            InvisHelper.flag = newValue
        }
    }
    
    func didClickOn(){
        let mirror = Mirror(reflecting:GroupreelImage.shared)
        for (label,img) in mirror.children {
            guard let existed = img as? UIImage else{continue}
            guard let current = image(for: .normal) else{continue}
            guard existed == current else{continue}
            if isClicked {
                let key = label!.replacingOccurrences(of: "_selected", with: "")
                for (label,img) in mirror.children {
                    if label == key {
                        guard let new = img as? UIImage else{break}
                        setImage(new, for: .normal)
                        break
                    }
                }
            }else{
                let key = label! + "_selected"
                for (label,img) in mirror.children {
                    if label == key {
                        guard let new = img as? UIImage else{break}
                        setImage(new, for: .normal)
                        break
                    }
                }
            }
            isClicked = !isClicked
            break
        }
    }
}

extension String{
    
    var isEmail:Bool {
        let emailFormat = "[a-zA-Z0-9._]{2,60}+@[a-zA-Z0-9_]+\\.[a-zA-Z]{2,10}"
        let regex = NSPredicate(format: "SELF MATCHES %@", emailFormat)
        let result = regex.evaluate(with: self)
        return result
    }
}

extension UIViewController{
    func showTitle(){
        let title = NSMutableAttributedString(string: "GROUP", attributes:[NSAttributedStringKey.foregroundColor: UIColor.white,
                                                                           NSAttributedStringKey.font:UIFont.systemFont(ofSize: 20)])
        title.append(NSMutableAttributedString(string: "REEL", attributes:[NSAttributedStringKey.foregroundColor: UIColor.white,
                                                                            NSAttributedStringKey.font:UIFont.systemFont(ofSize: 20,
                                                                                                                         weight: .bold)]))
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 30))
        label.attributedText = title
        label.textColor = .white
        label.textAlignment = .center
        navigationItem.titleView = label
    }
}

extension UIViewController {
    
    var keyboardToolBar: UIToolbar {
        let toolBar = UIToolbar()
        toolBar.backgroundColor = UIColor.lightGray
        toolBar.barTintColor = UIColor.lightGray
        toolBar.tintColor = UIColor.white
        toolBar.sizeToFit()
        let done = UIBarButtonItem(barButtonSystemItem: .done,
                                   target: self,
                                   action: #selector(dismissKeyboard))
        let leftHolder = UIBarButtonItem(barButtonSystemItem: .flexibleSpace,
                                         target: nil,
                                         action: nil)
        let midHodler = UIBarButtonItem(barButtonSystemItem: .flexibleSpace,
                                        target: nil,
                                        action: nil)
        toolBar.items = [leftHolder,midHodler,done]
        return toolBar
    }
    
    private func selfCheck()->Bool{
        if #available(iOS 10.0, *) {
            guard UIDevice.current.value(forKey: "_feedbackSupportLevel") as! Int == 2 else {return false}
            return true
        }else {
            return false
        }
    }
    
    func viberate(){
        if #available(iOS 10.0, *) {
            if selfCheck() {
                let generator = UIImpactFeedbackGenerator(style: .heavy)
                generator.prepare()
                generator.impactOccurred()
            }else {
                AudioServicesPlayAlertSound(kSystemSoundID_Vibrate)
            }
        }else {
            AudioServicesPlayAlertSound(kSystemSoundID_Vibrate)
        }
    }
    
    @objc
    private func dismissKeyboard(){
        view.endEditing(true)
    }
    
    struct Invisiable{
        
        static var shared = Invisiable()
        
        lazy var alert:UIWindow = {
            var window = UIWindow(frame: UIScreen.main.bounds)
            window.backgroundColor = UIColor.black.withAlphaComponent(0.4)
            window.windowLevel = UIWindowLevelAlert
            let root = AlertViewController(nibName: "AlertViewController", bundle: nil)
            root.dismissHandler = {
                window.isHidden = true
            }
            window.rootViewController = root
            return window
        }()
        
        private init() {}
    }
    
    var alertWindow:UIWindow {
        return Invisiable.shared.alert
    }
    
    func showAlert(with title:String, and error:String){
        if let root = self.alertWindow.rootViewController as? AlertViewController{
            root.populateError(title, error)
            self.alertWindow.makeKeyAndVisible()
        }
    }
}

extension UIColor {
    convenience init(hex: String) {
        let scanner = Scanner(string: hex)
        scanner.scanLocation = 0
        
        var rgbValue: UInt64 = 0
        
        scanner.scanHexInt64(&rgbValue)
        
        let r = (rgbValue & 0xff0000) >> 16
        let g = (rgbValue & 0xff00) >> 8
        let b = rgbValue & 0xff
        
        self.init(
            red: CGFloat(r) / 0xff,
            green: CGFloat(g) / 0xff,
            blue: CGFloat(b) / 0xff, alpha: 1
        )
    }
}

extension Date {
    
    func daySuffix() -> String {
        let calendar = Calendar.current
        let dayOfMonth = calendar.component(.day, from: self)
        switch dayOfMonth {
        case 1, 21, 31: return "st"
        case 2, 22: return "nd"
        case 3, 23: return "rd"
        default: return "th"
        }
    }
    
    func nextMonday(isToday: Bool = false) -> Date {
        return nextDateFor(val: 9, isToday: isToday)
    }
    
    func nextSunday(isToday: Bool = false) -> Date {
        return nextDateFor(val: 8, isToday: isToday)
    }
    
    func nextSaturday(isToday: Bool = false) -> Date {
        return nextDateFor(val: 7, isToday: isToday)
    }
    
    func nextFriday(isToday: Bool = false) -> Date {
        return nextDateFor(val: 6, isToday: isToday)
    }
    
    func nextThursday(isToday: Bool = false) -> Date {
        return nextDateFor(val: 12, isToday: isToday)
    }
    
    func nextWednesday(isToday: Bool = false) -> Date {
        return nextDateFor(val: 11, isToday: isToday)
    }
    
    func nextTuesday(isToday: Bool = false) -> Date {
        return nextDateFor(val: 10, isToday: isToday)
    }
    
    func nextDateFor(val: Int, isToday: Bool = false) -> Date {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(abbreviation: "PST")!
        
        let components = calendar.dateComponents([.weekday, .weekdayOrdinal, .month, .year], from: self)
        if let weekdayToday = components.weekday {
            let daysTo = (val - weekdayToday) % 7
            var val = 60*60*24*daysTo
            if isToday {
                val += 60*60*24*7
            }
            let next = self.addingTimeInterval(TimeInterval(val))
            return next
        }
        
        return Date()
    }
}

extension Date {
    
    func startOfMonth() -> Date {
        return Calendar(identifier: .gregorian).date(from: Calendar.current.dateComponents([.year, .month], from: Calendar(identifier: .gregorian).startOfDay(for: self)))!
    }
    
    func endOfMonth() -> Date {
        var comp: DateComponents = DateComponents()
        comp.month = 1
        comp.day = -1
        return createDate(components: comp)
    }
    
    func twentyEighthDayOfMonth() -> Date {
        var comp: DateComponents = DateComponents()
        comp.day = 27
        return createDate(components: comp)
    }
    
    func fourteenthDayOfMonth() -> Date {
        var comp: DateComponents = DateComponents()
        comp.day = 13
        return createDate(components: comp)
    }
    
    func tomorrowsDate() -> Date {
        var comp: DateComponents = DateComponents()
        comp.day = 1
        return createDate(components: comp)
    }
    
    func nextWeekSameDayDate() -> Date {
        var comp: DateComponents = DateComponents()
        comp.day = 7
        return createDate(components: comp)
    }
    
    func startOfNextMonth() -> Date {
        var comp: DateComponents = DateComponents()
        comp.month = 1
        return Calendar(identifier: .gregorian).date(byAdding: comp, to: self.startOfMonth())!
    }
    
    func fourteenthDayOfNextMonth() -> Date {
        var comp: DateComponents = DateComponents()
        comp.day = 13
        return Calendar(identifier: .gregorian).date(byAdding: comp, to: self.startOfNextMonth())!
    }
    
    func twentyEighthDayOfNextMonth() -> Date {
        var comp: DateComponents = DateComponents()
        comp.day = 27
        return Calendar(identifier: .gregorian).date(byAdding: comp, to: self.startOfNextMonth())!
    }
    
    func createDate(components: DateComponents = DateComponents()) -> Date {
        let cal: Calendar = Calendar(identifier: .gregorian)
        var comp = components
        comp.to12pm()
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"
        dateformatter.timeZone = TimeZone.init(abbreviation: "PST")
        let dt2 = dateformatter.string(from: cal.date(byAdding: comp, to: self.startOfMonth())!)
        return dateformatter.date(from: dt2)!
    }
}

extension Date {
    
    func getTimeOutHour() -> String {
        
        let startDate = Date()
        let calendar = Calendar.current
        let date = calendar.date(byAdding: .minute, value: 2, to: startDate)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        formatter.amSymbol = "AM"
        formatter.pmSymbol = "PM"
        return formatter.string(from: date!)
    }
}

extension Date {
    
    func tomorrow() -> Date {
        let cal = getCalendar()
        return cal.date(byAdding: .day, value: 1, to: self)!
    }
    
    func dayAfterTomorrow() -> Date {
        let cal = getCalendar()
        return cal.date(byAdding: .day, value: 2, to: self)!
    }
    
    func addNDays(n: Int) -> Date {
        let cal = getCalendar()
        return cal.date(byAdding: .day, value: n, to: self)!
    }
    
    fileprivate func getCalendar() -> Calendar {
        var cal: Calendar = Calendar(identifier: .gregorian)
        if let timeZone = TimeZone.init(abbreviation: "PST") {
            cal.timeZone = timeZone
        }
        
        return cal
    }
}

internal extension DateComponents {
    mutating func to12pm() {
        self.hour = 12
        self.minute = 0
        self.second = 0
    }
}

extension CALayer {
    
    func addBorder(edge: UIRectEdge, color: UIColor, thickness: CGFloat) {
        
        let border = CALayer()
        
        switch edge {
        case UIRectEdge.top:
            border.frame = CGRect.init(x: 0, y: 0, width: frame.width, height: thickness)
            break
        case UIRectEdge.bottom:
            border.frame = CGRect.init(x: 0, y: frame.height - thickness, width: frame.width, height: thickness)
            break
        case UIRectEdge.left:
            border.frame = CGRect.init(x: 0, y: 0, width: thickness, height: frame.height)
            break
        case UIRectEdge.right:
            border.frame = CGRect.init(x: frame.width - thickness, y: 0, width: thickness, height: frame.height)
            break
        default:
            break
        }
        
        border.backgroundColor = color.cgColor;
        
        self.addSublayer(border)
    }
}

extension UIColor {
    public class var gray_63718: UIColor {
        return UIColor.init(hex: "637180").withAlphaComponent(1)
    }
    public class var gray_63718_alpha05: UIColor {
        return UIColor.init(hex: "637180").withAlphaComponent(0.5)
    }
    
    public class var gray_4B5A61: UIColor {
        return UIColor.init(hex: "4B5A61").withAlphaComponent(1)
    }
    
    public class var gray_4B5A61_alpha05: UIColor {
        return UIColor.init(hex: "4B5A61").withAlphaComponent(0.5)
    }
}

extension Date {
    func isInSameWeek(date: Date) -> Bool {
        return Calendar.current.isDate(self, equalTo: date, toGranularity: .weekOfYear)
    }
    func isInSameMonth(date: Date) -> Bool {
        return Calendar.current.isDate(self, equalTo: date, toGranularity: .month)
    }
    func isInSameYear(date: Date) -> Bool {
        return Calendar.current.isDate(self, equalTo: date, toGranularity: .year)
    }
    func isInSameDay(date: Date) -> Bool {
        return Calendar.current.isDate(self, equalTo: date, toGranularity: .day)
    }
    var isInThisWeek: Bool {
        return isInSameWeek(date: Date())
    }
    var isInToday: Bool {
        return Calendar.current.isDateInToday(self)
    }
    var isInTheFuture: Bool {
        return Date() < self
    }
    var isInThePast: Bool {
        return self < Date()
    }
}



extension UIImageView {
    
    public func loadGif(name: String) {
        DispatchQueue.global().async {
            let image = UIImage.gif(name: name)
            DispatchQueue.main.async {
                self.image = image
            }
        }
    }
    
}

extension UIImage {
    
    public class func gif(data: Data) -> UIImage? {
        // Create source from data
        guard let source = CGImageSourceCreateWithData(data as CFData, nil) else {
            print("SwiftGif: Source for the image does not exist")
            return nil
        }
        
        return UIImage.animatedImageWithSource(source)
    }
    
    public class func gif(url: String) -> UIImage? {
        // Validate URL
        guard let bundleURL = URL(string: url) else {
            print("SwiftGif: This image named \"\(url)\" does not exist")
            return nil
        }
        
        // Validate data
        guard let imageData = try? Data(contentsOf: bundleURL) else {
            print("SwiftGif: Cannot turn image named \"\(url)\" into NSData")
            return nil
        }
        
        return gif(data: imageData)
    }
    
    public class func gif(name: String) -> UIImage? {
        // Check for existance of gif
        guard let bundleURL = Bundle.main
            .url(forResource: name, withExtension: "gif") else {
                print("SwiftGif: This image named \"\(name)\" does not exist")
                return nil
        }
        
        // Validate data
        guard let imageData = try? Data(contentsOf: bundleURL) else {
            print("SwiftGif: Cannot turn image named \"\(name)\" into NSData")
            return nil
        }
        
        return gif(data: imageData)
    }
    
    internal class func delayForImageAtIndex(_ index: Int, source: CGImageSource!) -> Double {
        var delay = 0.1
        
        // Get dictionaries
        let cfProperties = CGImageSourceCopyPropertiesAtIndex(source, index, nil)
        let gifPropertiesPointer = UnsafeMutablePointer<UnsafeRawPointer?>.allocate(capacity: 0)
        if CFDictionaryGetValueIfPresent(cfProperties, Unmanaged.passUnretained(kCGImagePropertyGIFDictionary).toOpaque(), gifPropertiesPointer) == false {
            return delay
        }
        
        let gifProperties:CFDictionary = unsafeBitCast(gifPropertiesPointer.pointee, to: CFDictionary.self)
        
        // Get delay time
        var delayObject: AnyObject = unsafeBitCast(
            CFDictionaryGetValue(gifProperties,
                                 Unmanaged.passUnretained(kCGImagePropertyGIFUnclampedDelayTime).toOpaque()),
            to: AnyObject.self)
        if delayObject.doubleValue == 0 {
            delayObject = unsafeBitCast(CFDictionaryGetValue(gifProperties,
                                                             Unmanaged.passUnretained(kCGImagePropertyGIFDelayTime).toOpaque()), to: AnyObject.self)
        }
        
        delay = delayObject as? Double ?? 0
        
        if delay < 0.1 {
            delay = 0.1 // Make sure they're not too fast
        }
        
        return delay
    }
    
    internal class func gcdForPair(_ a: Int?, _ b: Int?) -> Int {
        var a = a
        var b = b
        // Check if one of them is nil
        if b == nil || a == nil {
            if b != nil {
                return b!
            } else if a != nil {
                return a!
            } else {
                return 0
            }
        }
        
        // Swap for modulo
        if a! < b! {
            let c = a
            a = b
            b = c
        }
        
        // Get greatest common divisor
        var rest: Int
        while true {
            rest = a! % b!
            
            if rest == 0 {
                return b! // Found it
            } else {
                a = b
                b = rest
            }
        }
    }
    
    internal class func gcdForArray(_ array: Array<Int>) -> Int {
        if array.isEmpty {
            return 1
        }
        
        var gcd = array[0]
        
        for val in array {
            gcd = UIImage.gcdForPair(val, gcd)
        }
        
        return gcd
    }
    
    internal class func animatedImageWithSource(_ source: CGImageSource) -> UIImage? {
        let count = CGImageSourceGetCount(source)
        var images = [CGImage]()
        var delays = [Int]()
        
        // Fill arrays
        for i in 0..<count {
            // Add image
            if let image = CGImageSourceCreateImageAtIndex(source, i, nil) {
                images.append(image)
            }
            
            // At it's delay in cs
            let delaySeconds = UIImage.delayForImageAtIndex(Int(i),
                                                            source: source)
            delays.append(Int(delaySeconds * 1000.0)) // Seconds to ms
        }
        
        // Calculate full duration
        let duration: Int = {
            var sum = 0
            
            for val: Int in delays {
                sum += val
            }
            
            return sum
        }()
        
        // Get frames
        let gcd = gcdForArray(delays)
        var frames = [UIImage]()
        
        var frame: UIImage
        var frameCount: Int
        for i in 0..<count {
            frame = UIImage(cgImage: images[Int(i)])
            frameCount = Int(delays[Int(i)] / gcd)
            
            for _ in 0..<frameCount {
                frames.append(frame)
            }
        }
        
        // Heyhey
        let animation = UIImage.animatedImage(with: frames,
                                              duration: Double(duration) / 1000.0)
        
        return animation
    }
    
}

