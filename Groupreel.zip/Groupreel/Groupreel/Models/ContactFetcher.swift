//
//  ContactFetcher.swift
//  Groupreel
//
//  Created by Xu, Jay on 1/16/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import Foundation
import ContactsUI

class ContactFetcher {
    
    class func getContacts(filter: ContactsFilter = .none) -> [Phone] {
        
        let contactStore = CNContactStore()
        let keysToFetch = [
            CNContactFormatter.descriptorForRequiredKeys(for: .fullName),
            CNContactPhoneNumbersKey,
            CNContactEmailAddressesKey,
            CNContactThumbnailImageDataKey] as [Any]
        
        var allContainers: [CNContainer] = []
        do {
            allContainers = try contactStore.containers(matching: nil)
        } catch {
            
        }
        
        var results: [Phone] = []
        
        for container in allContainers {
            let fetchPredicate = CNContact.predicateForContactsInContainer(withIdentifier: container.identifier)
            
            do {
                let containerResults = try contactStore.unifiedContacts(matching: fetchPredicate, keysToFetch: keysToFetch as! [CNKeyDescriptor])
                for result in containerResults {
                    let name = result.givenName + result.familyName
                    if let phone = result.phoneNumbers.first {
                        results.append(Phone(name: name, phone: phone.value.stringValue))
                    }
                }
            } catch {
                
            }
        }
        return results
    }
}

enum ContactsFilter {
    case none
    case mail
    case message
}

