//
//  Cache.swift
//  Groupreel
//
//  Created by Xu, Jay on 1/26/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import Foundation

struct Cache{
    
    static var currentUser:String = ""
    
    @available (*, unavailable)
    init() {}
    
    
}
