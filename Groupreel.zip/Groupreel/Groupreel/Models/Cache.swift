//
//  Cache.swift
//  Groupreel
//
//  Created by Xu, Jay on 1/26/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import Foundation

struct Cache{
    
    static var currentUser:String = ""
    static var event:String = ""
    static var eventID = ""
    static var price:Double = 0
    static var ready = false
    static var bioAuth:Bool {
        get{
            return keychain.getBool("bioAuth") ?? false
        }
        set{
            keychain.set(newValue, forKey: "bioAuth")
        }
    }
    
    private static let keychain = KeychainSwift()
    
    @available (*, unavailable)
    init() {}
    
    static func save(_ name:String,pass:String){
        keychain.set(name, forKey: "user")
        keychain.set(pass, forKey: "password")
    }
    
    static func authenticateUser(_ completion:@escaping ((Bool,[Event]?,String?)->Void)) {
        guard let name = keychain.get("user") else {
            completion(false, nil,"Token expired, please login with username and password.")
            return
        }
        guard let pass = keychain.get("password") else{
            completion(false, nil,"Token expired, please login with username and password.")
            return
        }
        Cache.currentUser = name
        let request = AuthRequest(name: name, pass: pass)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                self.fetchEvents({ (flag, events,error) in
                    completion(flag,events,error)
                })
            }else if let e = response?.error{
                self.currentUser = ""
                completion(false, nil, e.description)
            }else if let e = error {
                self.currentUser = ""
                completion(false, nil, e.description)
            }
        }
    }
    
    private static func fetchEvents(_ completion:@escaping ((Bool,[Event]?,String?)->Void)){
        let request = AllEventRequest(with: Cache.currentUser)
        WebServiceHandler().send(r: request) { (success, response, error) in
            if success {
                self.currentUser = ""
                completion(true,response?.events, nil)
            }else if let e = response?.error{
                completion(false, nil, e.description)
            }else if let e = error {
                completion(false, nil, e.description)
            }
        }
        let r = PriceRequest(duration: 1)
        WebServiceHandler().send(r: r) { (success, response, error) in
            self.price = response?.unit ?? 0
        }
    }
}
