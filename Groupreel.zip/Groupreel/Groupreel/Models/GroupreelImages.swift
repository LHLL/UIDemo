//
//  GroupreelImages.swift
//  Groupreel
//
//  Created by Lynn on 12/11/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import Foundation

struct GroupreelImage {
    
    static var shared = GroupreelImage()
    
    private init(){}
    
    let homeImage = IonIcons.image(withIcon: ion_android_home,
                                   iconColor: .white,
                                   iconSize: 30,
                                   imageSize: CGSize(width: 30,
                                                     height: 30))
    
    let homeImage_selected = IonIcons.image(withIcon: ion_android_home,
                                            iconColor: GroupreelColor.selectedColor,
                                            iconSize: 30,
                                            imageSize: CGSize(width: 30,
                                                              height: 30))
    
    let eventImage = IonIcons.image(withIcon: ion_calendar,
                                    iconColor: UIColor.white,
                                    iconSize: 30,
                                    imageSize: CGSize(width: 30,
                                                      height: 30))
    
    let eventImage_selected = IonIcons.image(withIcon: ion_calendar,
                                             iconColor: GroupreelColor.selectedColor,
                                             iconSize: 30,
                                             imageSize: CGSize(width: 30,
                                                               height: 30))
    
    let MessageImage = IonIcons.image(withIcon: ion_ios_email_outline,
                                      iconColor: .white,
                                      iconSize: 30,
                                      imageSize: CGSize(width: 30,
                                                        height: 30))
    
    let MessageImage_selected = IonIcons.image(withIcon: ion_ios_email_outline,
                                               iconColor: GroupreelColor.selectedColor,
                                               iconSize: 30,
                                               imageSize: CGSize(width: 30,
                                                                 height: 30))
    
    let SettingImage = IonIcons.image(withIcon: ion_ios_gear_outline,
                                      iconColor: .white,
                                      iconSize: 30,
                                      imageSize: CGSize(width: 30,
                                                        height: 30))
    
    let SettingImage_selected = IonIcons.image(withIcon: ion_ios_gear_outline,
                                               iconColor: GroupreelColor.selectedColor,
                                               iconSize: 30,
                                               imageSize: CGSize(width: 30,
                                                                 height: 30))
    
    let cameraImage = IonIcons.image(withIcon: ion_record,
                                     iconColor: UIColor(displayP3Red: 232/255.0,
                                                        green: 93/255.0,
                                                        blue: 90/255.0,
                                                        alpha: 1),
                                     iconSize: 80,
                                     imageSize: CGSize(width: 80,
                                                       height: 80))
    
    let errorImage = IonIcons.image(withIcon: ion_ios_information_outline,
                                    iconColor: GroupreelColor.errorColor,
                                    iconSize: 15,
                                    imageSize: CGSize(width: 15,
                                                      height: 15))
    
    let backImg = IonIcons.image(withIcon: ion_chevron_left,
                                 iconColor: .white,
                                 iconSize: 25,
                                 imageSize: CGSize(width: 25,
                                                   height: 25))
    
    let checkImg = IonIcons.image(withIcon: ion_checkmark_round,
                                  iconColor: UIColor(displayP3Red: 76/25500,
                                                     green: 197/255.0,
                                                     blue: 106/255.0,
                                                     alpha: 1),
                                  iconSize: 25,
                                  imageSize: CGSize(width: 25,
                                                    height: 25))
    
    let filmImage = IonIcons.image(withIcon: ion_film_marker,
                                   iconColor: UIColor(displayP3Red: 232/255.0,
                                                      green: 93/255.0,
                                                      blue: 90/255.0,
                                                      alpha: 1),
                                   iconSize: 30,
                                   imageSize: CGSize(width: 30,
                                                     height: 30))
    
    
}
