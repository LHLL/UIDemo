//
//  Phone.swift
//  Groupreel
//
//  Created by Lynn on 11/14/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import Foundation

struct Phone {
    let name:String
    let phone:String
    
    init(name:String, phone:String) {
        self.name = name
        self.phone = phone
    }
}
