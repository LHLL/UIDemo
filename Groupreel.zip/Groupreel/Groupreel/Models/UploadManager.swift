//
//  UploadManager.swift
//  Groupreel
//
//  Created by Lynn on 8/31/17.
//  Copyright © 2017 Lynne. All rights reserved.
//

import Foundation
import AWSS3
import AWSCore

protocol UploadManagerDelegate:class {
    func didEncounter(error:String)
    func doneDoneDone(id:Int)
}

class UploadManager:NSObject {

    static var shared = UploadManager()
    weak var delegate:UploadManagerDelegate?
    private var count = 0
    
    private override init() {
        super.init()
        let accessKey = "AKIAJKPWXC2ZDIAB7TIQ"
        let secretKey = "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"
        let credentialsProvider = AWSStaticCredentialsProvider(accessKey: accessKey, secretKey: secretKey)
        let configuration = AWSServiceConfiguration(region: AWSRegionType.USEast1, credentialsProvider: credentialsProvider)
        AWSServiceManager.default().defaultServiceConfiguration = configuration
    }
    
    private func generateRequest(with url:URL,bucket:String, and name:String)->AWSS3TransferManagerUploadRequest{
        let S3BucketName = "groupreel"
        let uploadRequest = AWSS3TransferManagerUploadRequest()!
        uploadRequest.body = url
        uploadRequest.key = name
        uploadRequest.bucket = S3BucketName
        uploadRequest.contentType = "video/mp4"
        uploadRequest.acl = .publicRead
        return uploadRequest
    }
    
    func uploadInBackground(with url:URL,bucket:String ,and name:String){
        let getPreSignedURLRequest = AWSS3GetPreSignedURLRequest()
        getPreSignedURLRequest.bucket = bucket
        getPreSignedURLRequest.key = name
        getPreSignedURLRequest.httpMethod = .PUT
        getPreSignedURLRequest.expires = Date(timeIntervalSinceNow: 3600)
        getPreSignedURLRequest.contentType = "video/mp4"
        
        AWSS3PreSignedURLBuilder.default().getPreSignedURL(getPreSignedURLRequest).continueWith { (task:AWSTask<NSURL>) -> Any? in
            if let error = task.error {
                print("Error: \(error)")
                self.delegate?.didEncounter(error: error.localizedDescription)
                return nil
            }
            guard let presignedURL = task.result else{return nil}
            var request = URLRequest(url: presignedURL as URL)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.httpMethod = "PUT"
            request.setValue("video/mp4",
                             forHTTPHeaderField: "Content-Type")
            let config = URLSessionConfiguration.background(withIdentifier: "Upload")
            let session = URLSession(configuration: config,
                                     delegate: self, delegateQueue: OperationQueue.current)
            let uploadTask: URLSessionTask = session.uploadTask(with: request,
                                                                fromFile: url)
            uploadTask.taskDescription = "\(self.count)"
            self.count += 1
            uploadTask.resume()
            return nil
        }
    }
    
    func upload(from location:URL, bucket:String, with name:String) {
        let r = generateRequest(with: location,bucket: bucket, and: name)
        let transferManager = AWSS3TransferManager.default()
        transferManager.upload(r).continueWith(block: { (task: AWSTask) -> Any? in
            if let error = task.error {
                self.delegate?.didEncounter(error: error.localizedDescription)
            }else if task.result != nil {
                //self.delegate?.doneDoneDone()
            }
            return nil
        })
    }
    
    func terminate(){
        let transferManager = AWSS3TransferManager.default()
        transferManager.cancelAll()
    }
}

extension UploadManager:URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?){
        if error != nil {
            delegate?.didEncounter(error: error!.localizedDescription)
        }else{
            delegate?.doneDoneDone(id:Int(task.taskDescription!)!)
        }
    }
}
