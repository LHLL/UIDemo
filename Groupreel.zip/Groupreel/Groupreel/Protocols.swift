//
//  Protocols.swift
//  Groupreel
//
//  Created by 李玲 on 2/6/18.
//  Copyright © 2018 Lynne. All rights reserved.
//

import Foundation

@objc protocol Reversable { 
    @objc func goBack()
}

extension UIViewController:Reversable{
    func goBack(){
        navigationController?.popViewController(animated: true)
    }
}
