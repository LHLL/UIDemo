//
//  ionicons.h
//  ionicons
//
//  Created by sweetman on 5/1/17.
//  Copyright © 2017 TapTemplate. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ionicons.
FOUNDATION_EXPORT double ioniconsVersionNumber;

//! Project version string for ionicons.
FOUNDATION_EXPORT const unsigned char ioniconsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ionicons/PublicHeader.h>


