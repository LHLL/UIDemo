//
//  ionicons.h
//  ionicons
//
//  Created by sweetman on 5/1/17.
//  Copyright © 2017 David Sweetman. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ionicons.
FOUNDATION_EXPORT double ioniconsVersionNumber;

//! Project version string for ionicons.
FOUNDATION_EXPORT const unsigned char ioniconsVersionString[];

#import "IonIcons-iOS.h"
