//
//  TransactionHistoryViewController.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/22/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

class TransactionHistoryViewController: UIViewController {
    
    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var fakeHeader: UIView!
    @IBOutlet weak var circularView: UIView!
    @IBOutlet weak var transactionList: UITableView!
    @IBOutlet weak var searchTF: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    fileprivate let titles = ["PENDING","TODAY","APRIL 5, 2017"]
    private let searchImg = UIImage(named:"Search_Active_Icon")
    fileprivate var selected = IndexPath(row: -1, section: -1)
    
    //MARK:Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUIComponents()
        circularView.layer.cornerRadius = circularView.bounds.height/2
    }
    
    //MARK:UI Setup
    private func configureUIComponents(){
        tableViewCellEnrollment()
        searchTFSetup()
        automaticallyAdjustsScrollViewInsets = false
    }
    
    private func searchTFSetup(){
        searchTF.layer.borderColor = UIColor(red: 217/255.0,
                                             green: 219/255.0,
                                             blue: 220/255.0,
                                             alpha: 1).cgColor
        searchTF.layer.borderWidth = 1
        guard searchImg != nil else{
            assert(false, "(TransactionHistoryViewController):Image named Search_Active_Icon does not exist")
            return
        }
        let searchView =  UIImageView(image: searchImg)
        searchTF.leftView = searchView
        searchTF.layer.sublayerTransform = CATransform3DMakeTranslation(16, 0, 0)
        searchTF.leftViewMode = .unlessEditing
        searchTF.editingRect(forBounds: searchTF.bounds.insetBy(dx: 10, dy: 0))
        searchTF.textRect(forBounds: searchTF.bounds.insetBy(dx: 10, dy: 0))
        searchTF.delegate = self
        statusLabel.text = "No Transactions Found\nBy That Name\n\nSearch by Name Category, Merchant,\nDate or Amount"
    }
    
    private func tableViewCellEnrollment(){
        transactionList.register(UINib(nibName: "DivisionCell", bundle: nil),
                                 forCellReuseIdentifier: "DivisionCell")
    }
    
    //MARK:UI Control
    fileprivate func updateFakeHeader(){
        guard let first = transactionList.visibleCells.first else{return}
        guard let cell = first as? DivisionCell else{return}
        headerLabel.text = cell.titleLabel.text
        if cell.titleLabel.text == "PENDING" {
            circularView.backgroundColor = .white
            circularView.layer.borderColor = TransactionUtility.uglyRed.cgColor
            circularView.layer.borderWidth = 1
            circularView.layer.shadowPath = nil
            circularView.layer.shadowOpacity = 0
        }else {
            circularView.backgroundColor = TransactionUtility.uglyRed
            circularView.drawTransactionShadow()
        }
    }
}

extension TransactionHistoryViewController:UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TransactionUtility.transactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DivisionCell", for: indexPath) as! DivisionCell
        cell.data = TransactionUtility.transactions[indexPath.row]
        cell.titleLabel.text = titles[indexPath.row]
        cell.reloadHandler = { [unowned self] in
            self.tableView(tableView, didSelectRowAt: indexPath)
        }
        return cell
    }
}

extension TransactionHistoryViewController:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let count = CGFloat(TransactionUtility.transactions[indexPath.row].count)
        return indexPath == selected ? (66*(count-1) + 161) : (66*count + 18)
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = .clear
        return v
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selected = selected == indexPath ? IndexPath(row: -1, section: -1) : indexPath
        tableView.reloadData()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        fakeHeader.isHidden = scrollView.contentOffset.y <= 1
        updateFakeHeader()
    }
}

extension TransactionHistoryViewController:UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        transactionList.isHidden = true
        return true
    }
}
