//
//  ViewController.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/22/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let des = TransactionHistoryViewController(nibName: "TransactionHistoryViewController", bundle: nil)
        navigationController?.pushViewController(des, animated: true)
       //des.view.frame = view.frame
//        view.addSubview(des.view)
//        des.didMove(toParentViewController: self)
        
    }

}
