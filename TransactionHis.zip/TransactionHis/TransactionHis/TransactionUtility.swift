//
//  TransactionUtility.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/22/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

struct TransactionUtility {

    private init(){}
    
    static var transactions:[[SpendTransaction]] {
        get{
            return generateTransactions()
        }
    }
    
    static private func generateTransactions()->[[SpendTransaction]]{
        let t1 = SpendTransaction()
        t1.amount = "$7.02"
        t1.category = "Eating Out"
        t1.merchant = "Lee's Deli"
        let t2 = SpendTransaction()
        t2.amount = "+$15.00"
        t2.category = "Uncategories"
        t2.merchant = "Alex Evans"
        let t3 = SpendTransaction()
        t3.amount = "$4.60"
        t3.category = "Eating Out"
        t3.merchant = "Peet's Coffee Shop"
        let t4 = SpendTransaction()
        t4.amount = "$50.00"
        t4.category = "Uncategories"
        t4.merchant = "Squre"
        let t5 = SpendTransaction()
        t5.amount = "+$100.00"
        t5.category = "Deposit"
        t5.merchant = "Tyler Scott"
        return [[t1,t2],[t3],[t4,t5,t5,t3,t4,t5,t5,t3,t4,t5,t5,t3,t4,t5,t5,t3]]
    }
    
    static let uglyRed = UIColor(red: 208/255.0,
                                 green: 80/255.0,
                                 blue: 0,
                                 alpha: 1)
    
    //Can be used only inside draw method
    static func drawLine(From view:UIView, with dash:Bool = false){
        guard view.superview != nil else{
            assert(false, "(TransactionUtility):Try to draw (dash) line on nil.")
            return
        }
        let context: CGContext = UIGraphicsGetCurrentContext()!
        context.move(to: view.center)
        context.addLine(to: CGPoint(x: view.center.x,
                                    y: view.superview!.bounds.height))
        
        if dash {
            let dashes: [ CGFloat ] = [ 3.0, 3.0]
            context.setLineDash(phase: 0.0, lengths: dashes)
            view.backgroundColor = .white
            view.layer.borderColor = uglyRed.cgColor
            view.layer.borderWidth = 1
        }else {
            view.backgroundColor = uglyRed
            view.drawTransactionShadow()
        }
        
        context.setLineWidth(1)
        context.setLineCap(.butt)
        UIColor(colorLiteralRed: 143/255.0,
                green: 143/255.0,
                blue: 143/255.0,
                alpha: 1).set()
        context.strokePath()
    }
}

class SpendTransaction {
    
    var amount: String?
    var date: String?
    var merchant: String?
    var category:String?
}
