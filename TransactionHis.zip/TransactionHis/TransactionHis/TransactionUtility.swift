//
//  TransactionUtility.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/22/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

struct TransactionUtility {

    private init(){}
    
    static let uglyRed = UIColor(red: 208/255.0,
                                 green: 80/255.0,
                                 blue: 0,
                                 alpha: 1)
    
    //Can be used only inside draw method
    static func drawLine(From view:UIView, with dash:Bool = false){
        guard view.superview != nil else{
            assert(false, "Try to draw (dash) line on nil.")
            return
        }
        let context: CGContext = UIGraphicsGetCurrentContext()!
        context.move(to: view.center)
        context.addLine(to: CGPoint(x: view.center.x,
                                    y: view.superview!.bounds.height))
        
        if dash {
            let dashes: [ CGFloat ] = [ 3.0, 3.0]
            context.setLineDash(phase: 0.0, lengths: dashes)
            view.backgroundColor = .white
            view.layer.borderColor = uglyRed.cgColor
            view.layer.borderWidth = 1
        }else {
            view.backgroundColor = uglyRed
            view.drawTransactionShadow()
        }
        
        context.setLineWidth(1)
        context.setLineCap(.butt)
        UIColor(colorLiteralRed: 143/255.0,
                green: 143/255.0,
                blue: 143/255.0,
                alpha: 1).set()
        context.strokePath()
    }
}
