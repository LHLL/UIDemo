//
//  TableFactory.swift
//  P164Platform
//
//  Created by Leboeuf, Marc james on 4/4/17.
//  Copyright © 2017 Wells Fargo. All rights reserved.
//

import UIKit

protocol TableFactoryDataSource: class {
    /// Holds data coming from each Controller.
    var dataContainer: [Array<Any>] { get }
    
    /// Optional: TableViewSection Headers to add
    var headerViews: [TableViewSectionHeader]? { get }
    
    var footerViews: [TableViewSectionFooter]? {get}
    
    var cellEditActions: [TableViewCellEditActions]? { get }
}

final class TableFactory: NSObject {
    static let shared = TableFactory()
    private override init() { }
    
    fileprivate var vms: [TableTags] = [TableTags]()
    
    weak var delegate: TableFactoryDataSource?
    
    func registerViewModel(vm: TableTags) -> TableTags {
       
        for viewModel in vms {
            if object_getClassName(viewModel.type) == object_getClassName(vm.type) {
                return viewModel
            }
        }
        vms.append(vm)
        return vm
    }
}

extension TableFactory: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let _ = delegate else { return 0 }
        return delegate!.dataContainer.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let _ = delegate else { return 0 }
        return delegate!.dataContainer[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        for vm in vms {
            if let del = delegate, indexPath.section < del.dataContainer.count {
                let rowItems = del.dataContainer[indexPath.section]
                if indexPath.row < rowItems.count {
                    if object_getClassName(vm.type) == object_getClassName(rowItems[indexPath.row]) {
                        vm.updateData(data: delegate!.dataContainer[indexPath.section][indexPath.row])
                        if let _ = tableView.dequeueReusableCell(withIdentifier: vm.identifier) {
                            let cell = tableView.dequeueReusableCell(withIdentifier: vm.identifier, for: indexPath) as! TableCell
                            cell.configureCell(t: vm)
                            return cell
                        }
                    }
                }
            }
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        guard let actions = delegate?.cellEditActions else { return nil }
        for action in actions {
            if action.indexPath == indexPath {
                return action.editAction
            }
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        guard let actions = delegate?.cellEditActions else { return false }
        for action in actions {
            if action.indexPath == indexPath {
                return true
            }
        }
        return false
    }
    
}

extension TableFactory: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        for vm in vms {
            if let del = delegate, indexPath.section < del.dataContainer.count {
                let rowItems = del.dataContainer[indexPath.section]
                if indexPath.row < rowItems.count {
                    if object_getClassName(vm.type) == object_getClassName(rowItems[indexPath.row]) {
                        if let rowHeight = vm.rowHeight {
                            return rowHeight
                        }
                    }
                }
            }
        }
        
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        for vm in vms {
            if let del = delegate, indexPath.section < del.dataContainer.count {
                let rowItems = del.dataContainer[indexPath.section]
                if indexPath.row < rowItems.count {
                    if object_getClassName(vm.type) == object_getClassName(rowItems[indexPath.row]) {
                        vm.didSelectRow?(at: indexPath)
                        break
                    }
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        for vm in vms {
            if let del = delegate, indexPath.section < del.dataContainer.count {
                let rowItems = del.dataContainer[indexPath.section]
                if indexPath.row < rowItems.count {
                    if object_getClassName(vm.type) == object_getClassName(rowItems[indexPath.row]) {
                        vm.didDeselectRow?(at: indexPath)
                        break
                    }
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        guard let headers = delegate?.headerViews else { return nil }
        for header in headers {
            if header.section == section {
                for vm in vms {
                    if object_getClassName(vm.type) == object_getClassName(header.headerView) {
                        vm.updateData(data: header.headerView)
                        if let _ = tableView.dequeueReusableCell(withIdentifier: vm.identifier) {
                            let headerCell = tableView.dequeueReusableCell(withIdentifier: vm.identifier) as! TableCell
                            headerCell.configureCell(t: vm)
                            return headerCell
                        }
                    }
                }
            }
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        guard let headers = delegate?.headerViews else { return 0 }
        for header in headers {
            if header.section == section {
                return UITableViewAutomaticDimension
            }
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        guard let footers = delegate?.footerViews else { return nil }
        for footer in footers {
            if footer.section == section {
                for vm in vms {
                    if object_getClassName(vm.type) == object_getClassName(footer.footer) {
                        if let f = footer.footer as? TableCell {
                            f.configureCell(t: vm)
                            return f
                        }else {
                            return nil
                        }
                    }
                }
            }
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        guard let footers = delegate?.footerViews else { return 0 }
        for footer in footers {
            if footer.section == section {
                for vm in vms {
                    if object_getClassName(vm.type) == object_getClassName(footer.footer) {
                        return vm.rowHeight ?? 0
                    }
                }
            }
        }
        return 0
    }
    
}

typealias TableTags = TableCellDataSource&TableCellDelegate

@objc protocol TableCellDataSource {
    
    var identifier: String { get }
    
    var type: Any { get }
    
    @objc optional var rowHeight: CGFloat { get }
    
    /*
     Useage:
     class VM: Tags {
        private var realData: Int = 0
        func updateData(_ data: Any) {
            if data is Int {
            self.realData = data as! Int
         }
     }
    */
    func updateData(data: Any)
}

/// Empty Protocol here for you to add any methods you need.
@objc protocol TableCellDelegate {
    
    
    /// Tells the delegate that the specified row is now selected.
    ///
    /// - Parameter indexPath: An index path locating the new selected row in tableView.
    @objc optional func didSelectRow(at indexPath: IndexPath)
    
    
    /// Tells the delegate that the specified row is now deselected.
    ///
    /// - Parameter indexPath: An index path locating the new selected row in tableView.
    @objc optional func didDeselectRow(at indexPath: IndexPath)

}

/// Should be super class of Cell Instead of UITableViewCell
class TableCell: UITableViewCell {
    func configureCell<T>(t:T) {}
}

// MARK: - Utility 

struct TableViewSectionHeader {
    
    /// Pass Class Of Cell Type so VM can Handle
    var headerView: Any
    /// Section Header
    var section: Int
    
    init(headerView: Any, section: Int) {
        self.headerView = headerView
        self.section = section
    }
}

struct TableViewSectionFooter {
    
    /// Pass Class Of Cell Type so VM can Handle
    var footer: Any
    /// Section Header
    var section: Int
    
    init(footer: Any, section: Int) {
        self.footer = footer
        self.section = section
    }
}

struct TableViewCellEditActions {
    
    /// Pass Edit Actions to Display with Cell
    var editAction: [UITableViewRowAction]
    /// IndexPath For Cell in TableFactory
    var indexPath: IndexPath
    
    init(editAction: [UITableViewRowAction], indexPath: IndexPath) {
        self.editAction = editAction
        self.indexPath = indexPath
    }
}

extension TableFactoryDataSource {
    
    var headerViews: [TableViewSectionHeader]? { return nil }
    
    var cellEditActions: [TableViewCellEditActions]? { return nil }
}
