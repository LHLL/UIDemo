//
//  DivisionCell.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/22/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

class DivisionCell: UITableViewCell {

    @IBOutlet weak var circularView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var transactionTable: UITableView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        circularView.layer.cornerRadius = circularView.bounds.height/2
        transactionTable.register(UINib(nibName: "TransactionCell",
                                        bundle: nil),
                                  forCellReuseIdentifier: "TransactionCell")
        transactionTable.rowHeight = 56
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        TransactionUtility.drawLine(From: circularView,
                                    with:titleLabel.text == "PENDING")
    }
}

extension DivisionCell:UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TransactionCell",
                                                 for: indexPath)
        return cell
    }
}

extension DivisionCell:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = .clear
        return v
    }
}
