//
//  DivisionCell.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/22/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

class DivisionCell: UITableViewCell {

    @IBOutlet weak var circularView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var transactionTable: UITableView!
    @IBOutlet weak var countLabel: UILabel!
    
    fileprivate var si = IndexPath(row:-1,section:-1)
    
    var reloadHandler:(()->Void)?
    var data:[SpendTransaction]?{
        didSet{
            countLabel.text = "\(data!.count)"
            transactionTable.reloadData()
        }
    }
    
    //MARK:Life Cycle
    override func awakeFromNib() {
        super.awakeFromNib()
        circularView.layer.cornerRadius = circularView.bounds.height/2
        tableViewCellEnrollment()
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        //Context Matters
        TransactionUtility.drawLine(From: circularView,
                                    with:titleLabel.text == "PENDING")
    }
    
    //MARK:UI Setup
    private func tableViewCellEnrollment(){
        
        transactionTable.register(UINib(nibName: "TransactionCell",
                                        bundle: nil),
                                  forCellReuseIdentifier: "TransactionCell")
        transactionTable.register(UINib(nibName: "TransactionDetailCell", bundle: nil),
                                  forCellReuseIdentifier: "TransactionDetailCell")
    }
}

extension DivisionCell:UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return data == nil ? 0 : data!.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell!
        if si == indexPath {
            cell = tableView.dequeueReusableCell(withIdentifier: "TransactionDetailCell",
                                                 for: indexPath)
        }else{
            cell = tableView.dequeueReusableCell(withIdentifier: "TransactionCell",
                                                 for: indexPath)
            (cell as! TransactionCell).configureUI(With: data![indexPath.section])
        }
        return cell
    }
}

extension DivisionCell:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        si = si == indexPath ? IndexPath(row: -1, section: -1) : indexPath
        tableView.reloadData()
        reloadHandler?()
        if reloadHandler == nil {
            assert(false, "(DivisionCell):reloadHandler is nil")
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return si == indexPath ? 143 : 56
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = .clear
        return v
    }
}
