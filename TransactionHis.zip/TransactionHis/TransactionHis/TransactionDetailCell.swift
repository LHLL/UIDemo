//
//  TransactionDetailCell.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/23/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

class TransactionDetailCell: TableCell {

    @IBOutlet weak var categoryImg: UIImageView!
    @IBOutlet weak var catBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        uiSetup()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        //Context matters, redraw matters.
        drawTransactionShadow()
    }
    
    private func uiSetup(){
        layer.cornerRadius = 5
        
        categoryImg.layer.cornerRadius = categoryImg.bounds.height/2
        categoryImg.layer.borderColor = UIColor.lightGray.cgColor
        categoryImg.layer.borderWidth = 0.5
        
        let yourAttributes : [String: Any] = [
            NSFontAttributeName : UIFont.systemFont(ofSize: 12),
            NSForegroundColorAttributeName : catBtn.titleLabel!.textColor,
            NSUnderlineStyleAttributeName : NSUnderlineStyle.styleSingle.rawValue
        ]
        let attributeString = NSMutableAttributedString(string: "Uncategorized",
                                                        attributes: yourAttributes)
        catBtn.setAttributedTitle(attributeString, for: .normal)
    }
    
    //MARK:IBAction
    @IBAction func pickCategory(_ sender: UIButton) {
        
    }
}
