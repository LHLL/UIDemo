//
//  TotalBalanceCell.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/22/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

class TotalBalanceCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
