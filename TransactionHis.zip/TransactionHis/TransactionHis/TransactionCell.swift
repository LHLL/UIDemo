//
//  TransactionCell.swift
//  TransactionHis
//
//  Created by Xu, Jay on 8/22/17.
//  Copyright © 2017 Xu, Jay. All rights reserved.
//

import UIKit

class TransactionCell: TableCell {

    @IBOutlet weak var arrowImg: UIImageView!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var recipientLabel: UILabel!
    @IBOutlet weak var catgoryLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        layer.cornerRadius = 5
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        drawTransactionShadow()
    }
    
    func configureUI(With transaction:SpendTransaction) {
        amountLabel.text = transaction.amount
        recipientLabel.text = transaction.merchant
        catgoryLabel.text = transaction.category
    }
}

extension UIView{
    
    func drawTransactionShadow(){
        layer.shadowColor = UIColor(colorLiteralRed: 0/255.0,
                                    green: 0/255.0,
                                    blue: 0/255.0,
                                    alpha: 0.5).cgColor
        layer.shadowOffset = layer.cornerRadius == bounds.height/2 ? CGSize(width: 0, height: bounds.height/8) : CGSize.zero
        layer.shadowOpacity = layer.cornerRadius == bounds.height/2 ? 1 : 0.4
        layer.shadowRadius = 2
        layer.shadowPath = UIBezierPath(roundedRect: bounds,
                                        cornerRadius: layer.cornerRadius).cgPath
    }
}
