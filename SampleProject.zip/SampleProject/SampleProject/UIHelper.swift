//
//  UIHelper.swift
//  SampleProject
//
//  Created by 李玲 on 3/2/18.
//  Copyright © 2018 Intraspire. All rights reserved.
//

import UIKit

struct UIHelper{
    
    static func drawCircle(at point:CGPoint, _ fill:Bool = true) -> CAShapeLayer{
        let circlePath = UIBezierPath(arcCenter: point,
                                      radius: CGFloat(10),
                                      startAngle: CGFloat(0),
                                      endAngle:CGFloat(Double.pi * 2),
                                      clockwise: true)
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = circlePath.cgPath
        shapeLayer.fillColor = fill ? UIColor.red.cgColor : UIColor.clear.cgColor
        shapeLayer.strokeColor = UIColor.red.cgColor
        shapeLayer.lineWidth = 3.0
        
        return shapeLayer
    }
    
    static func drawLine(from start:CGPoint, to end:CGPoint, dashed:Bool = false) {
        let  path = UIBezierPath()
        path.move(to: start)
        path.addLine(to: end)
        if dashed {
            let  dashes: [ CGFloat ] = [ 8.0, 8.0 ]
            path.setLineDash(dashes, count: dashes.count, phase: 0.0)
            path.lineCapStyle = .butt
        }
        path.lineWidth = 3.0
        UIColor.red.set()
        path.stroke()
    }
    
    static var itemCounts:[Int] {
        return generateCounts()
    }
    
    private static func generateCounts()->[Int]{
        var count = 10
        var result = [Int]()
        while count > 0 {
            defer{count -= 1}
            result.append(Int(arc4random_uniform(10)) + 1)
        }
        return result
    }
    
}
