//
//  SecondViewController.swift
//  SampleProject
//
//  Created by 李玲 on 3/4/18.
//  Copyright © 2018 Intraspire. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var transactionHistory: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTransactionHistory()
    }
    
    private func configureTransactionHistory(){
        transactionHistory.estimatedRowHeight = 100
        transactionHistory.rowHeight = UITableViewAutomaticDimension
        let cellNib = UINib(nibName: "HistoryCell", bundle: nil)
        transactionHistory.register(cellNib, forCellReuseIdentifier: "HistoryCell")
    }
}

extension SecondViewController:UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Int(arc4random_uniform(10) + 1)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryCell", for: indexPath) as! HistoryCell
        cell.isPending = indexPath.section == 0
        return cell
    }
}

extension SecondViewController:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let v = Bundle.main.loadNibNamed("HeaderView",
                                         owner: nil,
                                         options: [:])?.last! as! HeaderView
        v.isPending = section != 0
        return v
    }
}
