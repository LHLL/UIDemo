//
//  HistoryCell.swift
//  SampleProject
//
//  Created by 李玲 on 3/4/18.
//  Copyright © 2018 Intraspire. All rights reserved.
//

import UIKit

class HistoryCell: UITableViewCell {

    @IBOutlet weak var borderView: UIView!
    
    var isPending = false{
        didSet{
            setNeedsDisplay()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        borderView.layer.borderColor = UIColor.lightGray.cgColor
        borderView.layer.borderWidth = 1
        borderView.layer.cornerRadius = 5
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        configureSeprator()
    }
    
    private func configureSeprator(){
        let start = CGPoint(x: 23,
                            y: 0)
        let end = CGPoint(x: 23,
                          y: frame.size.height)
        UIHelper.drawLine(from: start,
                          to: end,
                          dashed: isPending)
    }
    
}
