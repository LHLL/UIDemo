//
//  FirstViewController.swift
//  SampleProject
//
//  Created by 李玲 on 3/2/18.
//  Copyright © 2018 Intraspire. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var transactionHistory: UITableView!
    
    private var counts = [1,2,3,4,5,6,7,8,9,10]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTransactionHistory()
    }
    
    private func configureTransactionHistory(){
        transactionHistory.estimatedRowHeight = 100
        let cellNib = UINib(nibName: "ContainerCell", bundle: nil)
        transactionHistory.register(cellNib, forCellReuseIdentifier: "ContainerCell")
    }

}

extension FirstViewController:UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContainerCell", for: indexPath) as! ContainerCell
        cell.shouldFill = indexPath.section == 0
        cell.number = counts[indexPath.section]
        return cell
    }
}

extension FirstViewController:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let v = Bundle.main.loadNibNamed("HeaderView",
                                         owner: nil,
                                         options: [:])?.last! as! HeaderView
        v.isPending = section != 0
        return v
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //return CGFloat(counts[indexPath.section] * 123 + 20)
        return UITableViewAutomaticDimension
    }
}
