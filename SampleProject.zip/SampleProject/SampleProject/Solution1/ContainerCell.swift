//
//  ContainerCell.swift
//  SampleProject
//
//  Created by 李玲 on 3/2/18.
//  Copyright © 2018 Intraspire. All rights reserved.
//

import UIKit

class ContainerCell: UITableViewCell {

    @IBOutlet weak var container: UIStackView!
    
    var number = Int(arc4random_uniform(10) + 1)
    
    var shouldFill = false {
        didSet{
            setNeedsDisplay()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        populateTransactionHistory()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        for v in container.arrangedSubviews {
            container.removeArrangedSubview(v)
        }
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        configureSeprator()
    }
    
    func configureSeprator(){
        let start = CGPoint(x: 23,
                            y: 0)
        let end = CGPoint(x: 23,
                          y: frame.size.height)
        UIHelper.drawLine(from: start,
                          to: end,
                          dashed: shouldFill)
    }
    
    private func populateTransactionHistory(){
        for v in container.arrangedSubviews {
            container.removeArrangedSubview(v)
        }
        while number > 0 {
            defer{number -= 1}
            let cells = Bundle.main.loadNibNamed("TransactionCell",
                                                owner: nil,
                                                options: [:])
            if let cell = cells?.last as? TransactionCell {
                cell.frame = CGRect(x: 0,
                                    y: 0,
                                    width: container.bounds.width,
                                    height: 123)
                cell.layoutIfNeeded()
                container.addArrangedSubview(cell)
            }
        }
    }
    
}
