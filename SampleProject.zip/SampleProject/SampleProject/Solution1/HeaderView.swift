//
//  HeaderView.swift
//  SampleProject
//
//  Created by 李玲 on 3/2/18.
//  Copyright © 2018 Intraspire. All rights reserved.
//

import UIKit

class HeaderView: UIView {
    
    var isPending = false
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        let origin = CGPoint(x: 23, y: 20)
        layer.addSublayer(UIHelper.drawCircle(at: origin, isPending))
        let start = CGPoint(x: 23, y: 28)
        let end = CGPoint(x: 23, y: rect.size.height)
        UIHelper.drawLine(from: start,
                          to: end,
                          dashed: false)
        if isPending {
            let topStat = CGPoint(x: 23, y: 0)
            let topEnd = CGPoint(x: 23, y: 12)
            UIHelper.drawLine(from: topStat,
                              to: topEnd,
                              dashed: false)
        }
    }
    

}
