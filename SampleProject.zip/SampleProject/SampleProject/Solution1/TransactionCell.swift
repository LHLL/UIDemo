//
//  TransactionCell.swift
//  SampleProject
//
//  Created by 李玲 on 3/2/18.
//  Copyright © 2018 Intraspire. All rights reserved.
//

import UIKit

class TransactionCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        layer.borderColor = UIColor.lightGray.cgColor
        layer.borderWidth = 1
        layer.cornerRadius = 5
    }
    
}
